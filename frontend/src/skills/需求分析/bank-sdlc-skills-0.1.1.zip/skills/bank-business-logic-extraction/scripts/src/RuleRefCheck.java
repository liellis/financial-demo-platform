import org.json.*;import java.util.*;
public final class RuleRefCheck{
 public static void main(String[] a){Support.mainEntry(a,"S03",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));JSONArray rows=p.getJSONArray("rules");
  s.ids(rows,"br_id","BR_ID");s.evidenceRows(rows,"evidence");
  for(Object x:rows){JSONObject r=(JSONObject)x;Support.requireFields(s,r,"condition","action","source_kind");
   String kind=r.getString("source_kind");
   s.check("RULE_SOURCE",Arrays.asList("CODE_OBSERVED","DOCUMENTED","CONFIRMED").contains(kind),"Rule source category is explicit");
   if(kind.equals("CONFIRMED"))s.check("RULE_CONFIRMATION",Support.present(r,"confirmation_ref"),"Confirmed rule needs human/source reference");}
  if(Support.arr(p,"conflicts").length()>0)s.confirm("RULE_CONFLICT","Business/code conflicts require an owner decision");
  s.facts.put("rule_count",rows.length()).put("business_correctness","NOT_PROVEN");
 });}
}
