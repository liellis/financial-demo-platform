# 业务逻辑抽取

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`business-rules.json/md`；rules[{br_id,condition,action,exceptions,side_effects,source_kind,evidence,confirmation_ref}]、conflicts[]、unknowns[]。源码只证明实现行为，业务确认另有来源。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
