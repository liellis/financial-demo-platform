# S03 派生记录

- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S03-D01：将散文式探索改为“输入→条件→计算/状态变化→输出→副作用”的规则卡。
- S03-D02：新增金额、日期、交易、批量、权限、异常及外部依赖分类；每条规则区分 CODE_OBSERVED、DOCUMENTED、CONFIRMED。
- S03-D03：新增代码与制度不一致的冲突记录；禁止模型自选一方覆盖另一方。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
