---
name: bank-business-logic-extraction
description: 业务逻辑抽取；从指定代码入口抽取现有条件、计算、状态和副作用，区分代码观察与批准业务规则；不自动判定现状正确。
metadata:
  skill-id: "S03"
  version: "0.1.1"
---

# 业务逻辑抽取

从指定代码入口抽取现有条件、计算、状态和副作用，区分代码观察与批准业务规则；不自动判定现状正确。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取已定位符号、相关 DTO、Mapper、枚举、配置及批准的业务资料版本。
2. 逐分支记录前置条件和不变项，注明 null、空值、零值、负值及阈值分支。
3. 对金额记录类型、精度、舍入位置和依据；对日期记录业务日来源、时区和日终依赖。
4. 对持久化、消息、外部调用记录事务位置、失败路径、重复执行影响；看不到实现时标未知。
5. 为每条规则分配 BR ID，引用具体方法及片段摘要；参数来源区分代码常量、数据库、配置和人工说明。
6. 以“观察行为”生成规则与场景，给业务/QA列待确认问题，再交 S08/S09/S23。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类RuleRefCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`business-rules.json/md`；rules[{br_id,condition,action,exceptions,side_effects,source_kind,evidence,confirmation_ref}]、conflicts[]、unknowns[]。源码只证明实现行为，业务确认另有来源。

使用[业务模板](templates/business-rules.json)与[输出结构](schemas/business-rules.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需币种/利率、工作日历、账务术语、交易状态机及客户角色。缺规则依据时保留待确认，不补“行业通行”的金额或日历假设。

## 按需参考

- [bank-rule-taxonomy](references/bank-rule-taxonomy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
