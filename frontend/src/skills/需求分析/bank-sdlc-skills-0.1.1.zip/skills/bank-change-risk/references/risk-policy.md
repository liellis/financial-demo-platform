# risk-policy

仅支持受限when：path_glob、symbol_tag、impact_type、data_class、critical_operation、unknown_flag。多字段为AND，未提供字段返回UNKNOWN。多个命中取最高L级和动作交集；未命中不默认L1。

版本/owner/approval_ref缺失不授权MODIFY。L3只允许ANALYZE/DESIGN。银行规则样例未获批准不能运行生产变更。请求facts要有来源，规则程序不验证人类真实权限，强控制由客户环境承担。
