# S06 派生记录

- [templates/commands/constitution.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/constitution.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。

- S06-D01：将 F14 宪章改为只读治理来源；模型不得自己更新风险等级或补写批准人。
- S06-D02：新增受限规则 DSL：path_glob、symbol_tag、impact_type、data_class、critical_operation、unknown_flag；规则仅组合事实，不执行表达式代码。
- S06-D03：新增最高风险优先、未知不降级、规则冲突阻断和 L3 转人工流程；拒绝用低风险平均抵消关键命中。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
