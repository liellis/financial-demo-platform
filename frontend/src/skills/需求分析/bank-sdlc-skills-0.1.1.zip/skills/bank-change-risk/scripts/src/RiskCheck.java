import org.json.*;import java.util.*;
public final class RiskCheck{
 static Boolean match(JSONObject w,JSONObject facts){
  boolean unknown=false;
  for(String k:w.keySet()){
   if(k.equals("path_glob")){if(!facts.has("changed_paths"))unknown=true;else if(!Support.anyGlobAny(Support.arr(facts,"changed_paths"),w.getString(k)))return false;}
   else{
    String field;
    if(k.equals("symbol_tag"))field="symbol_tags";else if(k.equals("impact_type"))field="impact_types";
    else if(k.equals("data_class"))field="data_classes";else if(k.equals("critical_operation"))field="critical_operations";
    else if(k.equals("unknown_flag"))field="unknown_flags";else throw new IllegalArgumentException("Unsupported risk predicate");
    if(!facts.has(field))unknown=true;else if(!Support.strings(Support.arr(facts,field)).contains(w.getString(k)))return false;
   }
  }
  return unknown?null:Boolean.TRUE;
 }
 public static void main(String[] a){Support.mainEntry(a,"S06",s->{
  JSONObject policy=s.json(Evidence.profilePath(s.request.getString("policy"))),facts=s.request.getJSONObject("facts");
  s.bindChange(s.request.getString("change_id"));
  for(String field:Arrays.asList("changed_paths","symbol_tags","impact_types","data_classes","critical_operations","unknown_flags")){
   if(!facts.has(field))s.unknown("RISK_FIELD_MISSING","Risk facts incomplete: "+field);
   else Support.stringArray(facts,field);
  }
  if(facts.has("changed_paths"))for(Object x:GitDiff.changed(s,s.request.getString("base_commit"))){
   String path=((JSONObject)x).getString("path");
   if(!path.startsWith(".sdlc/")&&!path.startsWith(".opencode/skills/")&&!Support.strings(facts.getJSONArray("changed_paths")).contains(path))s.unknown("RISK_PATH_MISSING","Actual changed path absent from risk facts");
  }
  JSONArray matched=new JSONArray(),missing=new JSONArray();int level=0;
  Set<String> allowed=new LinkedHashSet<String>(Arrays.asList("ANALYZE","DESIGN","WRITE_TESTS","MODIFY"));
  boolean approved=Support.present(policy,"approval_ref")&&Support.present(policy,"owner")&&Support.present(policy,"version");
  s.check("POLICY_VERSION",Support.present(policy,"version"),"Policy has version");
  if(!approved)s.confirm("POLICY_APPROVAL","Policy cannot authorize implementation without customer approval/owner");
  for(Object x:policy.getJSONArray("rules")){
   JSONObject r=(JSONObject)x;JSONObject when=r.getJSONObject("when");if(when.length()==0)throw new IllegalArgumentException("Empty predicate");
   Boolean m=match(when,facts);
   if(m==null){missing.put(r.getString("id"));continue;}
   if(!m)continue;matched.put(r.getString("id"));
   if(r.optString("decision").equals("NEEDS_CONFIRMATION")){s.confirm("RULE_CONFIRMATION","Rule requires manual confirmation");allowed.retainAll(Arrays.asList("ANALYZE","DESIGN"));continue;}
   String l=r.getString("risk_level");int v=Arrays.asList("L1","L2","L3").indexOf(l)+1;if(v==0)throw new IllegalArgumentException("Invalid risk");
   level=Math.max(level,v);allowed.retainAll(Support.strings(r.getJSONArray("allowed_actions")));
  }
  if(missing.length()>0)s.unknown("RISK_FACTS_UNKNOWN","Some rule predicates have unknown inputs");
  if(level==0){s.unknown("NO_RISK_DECISION","No explicit risk rule established a level");allowed.retainAll(Arrays.asList("ANALYZE","DESIGN"));}
  if(!approved||level==3||!s.passed())allowed.retainAll(Arrays.asList("ANALYZE","DESIGN"));
  s.facts.put("change_id",s.changeId()).put("base_commit",s.request.getString("base_commit"))
   .put("diff_digest",GitDiff.fingerprint(s,s.request.getString("base_commit"))).put("policy_path",s.request.getString("policy"));
  s.facts.put("risk_level",level==0?JSONObject.NULL:"L"+level).put("matched_rules",matched).put("unknown_rules",missing)
   .put("allowed_actions",new JSONArray(allowed)).put("policy_sha256",Support.sha(s.file(s.request.getString("policy"))))
   .put("approval_is_reference_only",true);
 });}
}
