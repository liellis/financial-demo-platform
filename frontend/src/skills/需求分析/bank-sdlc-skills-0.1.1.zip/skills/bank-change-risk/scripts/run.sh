#!/bin/sh
set -eu
task_script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
task_java_home=$(printenv JAVA_HOME || true)
task_java=java
task_javac=javac
if [ -n "$task_java_home" ]; then
 task_java="$task_java_home/bin/java"
 task_javac="$task_java_home/bin/javac"
fi
if ! "$task_java" -version >/dev/null 2>&1 || ! "$task_javac" -version >/dev/null 2>&1; then
 printf '%s\n' '{"status":"BLOCKED","error_code":"ENV_MISSING"}'
 exit 3
fi
task_tmp_parent=$(printenv TMPDIR || true)
if [ -z "$task_tmp_parent" ]; then task_tmp_parent=/tmp; fi
task_temp=$(mktemp -d "$task_tmp_parent/bank-skill.XXXXXXXX")
trap 'rm -rf -- "$task_temp"' EXIT HUP INT TERM
find "$task_script_dir/src" "$task_script_dir/vendor" -name '*.java' -type f -print | while IFS= read -r task_source; do
 printf '"%s"\n' "$task_source"
done > "$task_temp/sources.txt"
if ! "$task_javac" -encoding UTF-8 -source 8 -target 8 -d "$task_temp/classes" @"$task_temp/sources.txt" 2>"$task_temp/compile.log"; then
 printf '%s\n' '{"status":"BLOCKED","error_code":"COMPILE_ERROR"}'
 exit 4
fi
"$task_java" -Xmx256m -Dfile.encoding=UTF-8 -cp "$task_temp/classes" RiskCheck "$@"
