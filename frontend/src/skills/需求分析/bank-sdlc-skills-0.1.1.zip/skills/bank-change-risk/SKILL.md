---
name: bank-change-risk
description: 变更风险评估；按客户批准规则评估变更风险和允许动作；关键操作或事实不全时停止自动实施。
metadata:
  skill-id: "S06"
  version: "0.1.1"
---

# 变更风险评估

按客户批准规则评估变更风险和允许动作；关键操作或事实不全时停止自动实施。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 profile 的 owner、版本、批准来源与有效性，无法确认则 NEEDS_CONFIRMATION。
2. 将 S03/S05、变更 diff 和路径分类形成 risk-facts；模型推断的标签保留来源等级。
3. 运行本项 RiskCheck，对明确事实执行规则并输出命中依据；未知字段单独返回，不按 false 处理。
4. 模型审阅规则盲区，如新路径未被配置、间接影响关键业务、数据迁移和权限放大。
5. 合成“规则结果＋人工待核实”；选择客户批准的动作：只分析、允许写测试、允许局部修改或转人工。
6. 将风险与有效规则版本交 S07/S14/S25；下游不得自行放松。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类RiskCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`risk.json/md`；facts[]、matched_rules[]、unknown_facts[]、risk_level、allowed_actions[]、manual_review_reasons[]、policy_ref。无有效规则时 risk_level 为 null，不能默认 L1。

使用[业务模板](templates/risk.json)与[输出结构](schemas/risk.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需关键操作、敏感数据、账务/支付/权限目录、变更等级和岗位决策表。L3 或治理冲突时停止自动生产代码修改，可继续只读设计。

## 按需参考

- [risk-policy](references/risk-policy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。
