---
name: bank-call-chain-analysis
description: 调用链分析；沿指定Java/Spring/MyBatis入口核对局部调用、数据和消息关系，显式保留反射及动态绑定未知边。
metadata:
  skill-id: "S04"
  version: "0.1.1"
---

# 调用链分析

沿指定Java/Spring/MyBatis入口核对局部调用、数据和消息关系，显式保留反射及动态绑定未知边。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 S02 入口、画像、方向和受控深度/节点上限；先报告分析范围。
2. 用宿主读取符号与配置；随附源码扫描器做词法候选提取，正确跳过注释和字符串，不冒充完整编译器。
3. 模型逐候选核对定义、参数和绑定，保留确认边与未解析边；重载、泛型、代理无法确认时不合并。
4. 对 Mapper/表、消息及批量触发单独追踪；异步边注明不是同一同步事务链。
5. 到外部系统、反射、动态 SQL 或遍历上限停止，输出边界；循环使用已访问节点去重。
6. 输出结构 JSON 和小型 Mermaid 视图；模型只画已确认边，未知边单独列示。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类GraphCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

词法候选入口scripts/source-hints.sh，请求source_files数组；只能用于待核实线索。

## 输出与验证

`call-chain.json/md`；nodes[]、edges[{from,to,type,evidence,resolution}]、unresolved_edges[]、truncation、analysis_scope。交 S05/S19 的图保留未知项。

使用[业务模板](templates/call-chain.json)与[输出结构](schemas/call-chain.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需框架扩展、RPC/消息规范、交易总线及作业注册方式。动态绑定缺失、CodeGraph 版本不符时退回局部证据，不能静默接受旧图。

## 按需参考

- [java-spring-relations](references/java-spring-relations.md)：对应步骤判断。
- [graph-import-contract](references/graph-import-contract.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
