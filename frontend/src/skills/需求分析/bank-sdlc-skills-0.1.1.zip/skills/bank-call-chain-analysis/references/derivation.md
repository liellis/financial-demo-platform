# S04 派生记录

- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S04-D01：新增节点类型 API、service、method、SQL、table、topic、job、external；边区分 CALL、CONFIG_BINDS、READ、WRITE、PUBLISH、CONSUME。
- S04-D02：新增 Spring 注入、接口候选、Mapper XML、定时任务和消息配置的受限分析清单。
- S04-D03：定义可选 CodeGraph 导入协议；基础版不依赖它，图导入必须带仓库与提交版本。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
