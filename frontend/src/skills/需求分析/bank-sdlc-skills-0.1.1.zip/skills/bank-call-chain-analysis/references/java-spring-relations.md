# java-spring-relations

先运行SourceHints得到词法候选，注释/字符串已排除，但定义/调用未区分。逐候选读声明、重载参数、实际实现与注入配置，证据不足不建确认边。

节点API/service/method/SQL/table/topic/job/external；边CALL/CONFIG_BINDS/READ/WRITE/PUBLISH/CONSUME。异步边、跨事务与外部边界显式注明。反射/动态SQL/代理与多实现保留unresolved。
