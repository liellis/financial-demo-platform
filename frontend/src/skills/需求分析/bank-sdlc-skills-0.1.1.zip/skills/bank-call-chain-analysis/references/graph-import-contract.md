# graph-import-contract

外部图谱最少包含repository_id、commit、tool_version、generated_at、nodes、edges、evidence及truncation。commit须与当前分析基线匹配，不能静默采用旧图。

导入后验证节点ID唯一、边端点存在、类型合法及来源可定位。图谱只增强证据，不免除业务影响判断；缺服务时回退局部分析，未知依赖传播到回归计划。
