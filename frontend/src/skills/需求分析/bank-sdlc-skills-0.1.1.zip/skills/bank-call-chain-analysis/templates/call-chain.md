# 调用链分析

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`call-chain.json/md`；nodes[]、edges[{from,to,type,evidence,resolution}]、unresolved_edges[]、truncation、analysis_scope。交 S05/S19 的图保留未知项。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
