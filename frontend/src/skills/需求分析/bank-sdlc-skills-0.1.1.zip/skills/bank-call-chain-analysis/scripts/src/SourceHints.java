import java.util.regex.*;import org.json.*;import java.nio.charset.*;
/** Lexical candidates, deliberately not a Java call graph. */
public final class SourceHints{
 static String strip(String t){
  StringBuilder b=new StringBuilder();int mode=0;
  for(int i=0;i<t.length();i++){char c=t.charAt(i),n=i+1<t.length()?t.charAt(i+1):0;
   if(mode==0){
    if(c=='/'&&n=='/'){mode=1;b.append("  ");i++;}
    else if(c=='/'&&n=='*'){mode=2;b.append("  ");i++;}
    else if(c=='"'&&i+2<t.length()&&t.charAt(i+1)=='"'&&t.charAt(i+2)=='"'){mode=5;b.append("   ");i+=2;}
    else if(c=='"'||c=='\''){mode=c=='"'?3:4;b.append(' ');}else b.append(c);
   }else if(mode==1){b.append(c=='\n'?'\n':' ');if(c=='\n')mode=0;}
   else if(mode==2){if(c=='*'&&n=='/'){b.append("  ");i++;mode=0;}else b.append(c=='\n'?'\n':' ');}
   else if(mode==5){if(c=='"'&&i+2<t.length()&&t.charAt(i+1)=='"'&&t.charAt(i+2)=='"'){b.append("   ");i+=2;mode=0;}else b.append(c=='\n'?'\n':' ');}
   else {if(c=='\\'&&n!=0){b.append("  ");i++;}else {b.append(c=='\n'?'\n':' ');if(c==(mode==3?'"':'\''))mode=0;}}
  }return b.toString();
 }
 public static void main(String[] a){Support.mainEntry(a,"S04",s->{
  JSONArray result=new JSONArray();
  for(Object x:s.request.getJSONArray("source_files")){
   String path=x.toString(),text=new String(Support.bounded(s.file(path),1024*1024),StandardCharsets.UTF_8);
   String clean=strip(text);Matcher m=Pattern.compile("\\b([A-Za-z_$][\\w$]*)\\s*\\(").matcher(clean);
   while(m.find()){String symbol=m.group(1);if(java.util.Arrays.asList("if","for","while","switch","catch","synchronized","new","super","this").contains(symbol))continue;
    int line=1;for(int j=0;j<m.start();j++)if(clean.charAt(j)=='\n')line++;
    result.put(new JSONObject().put("path",path).put("name",symbol).put("line",line).put("kind","UNRESOLVED_LEXICAL_CANDIDATE"));
    if(result.length()>2000)throw new java.io.IOException("Hint budget exceeded");
   }
  }
  s.facts.put("candidates",result);s.unknown("LEXICAL_ONLY","Definitions and calls are not distinguished; confirm bindings before creating graph edges");
 });}
}
