import org.json.*;import java.util.*;
public final class GraphCheck{
 public static void main(String[] a){Support.mainEntry(a,"S04",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));JSONArray nodes=p.getJSONArray("nodes"),edges=p.getJSONArray("edges");
  Set<String> ids=s.ids(nodes,"id","NODE_ID");s.check("GRAPH_BUDGET",nodes.length()<=s.request.optInt("max_nodes",300)&&edges.length()<=s.request.optInt("max_edges",600),"Graph budget");
  for(Object x:edges){JSONObject e=(JSONObject)x;s.check("GRAPH_EDGE",ids.contains(e.getString("from"))&&ids.contains(e.getString("to")),"Edge endpoints exist");
   s.check("EDGE_KIND",Arrays.asList("CALL","CONFIG_BINDS","READ","WRITE","PUBLISH","CONSUME").contains(e.getString("type")),"Explicit relation type");}
  s.evidenceRows(edges,"evidence");
  if(Support.arr(p,"unresolved_edges").length()>0||p.optBoolean("truncated"))s.unknown("GRAPH_PARTIAL","Unresolved or truncated graph must propagate to impact/regression");
  s.facts.put("nodes",nodes.length()).put("edges",edges.length());
 });}
}
