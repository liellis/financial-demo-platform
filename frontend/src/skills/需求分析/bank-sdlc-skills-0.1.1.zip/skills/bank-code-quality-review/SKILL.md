---
name: bank-code-quality-review
description: 代码质量审查；审查实际代码和测试diff的银行质量、安全及兼容风险，并核对已有扫描报告；不代替人工批准。
metadata:
  skill-id: "S17"
  version: "0.1.1"
---

# 代码质量审查

审查实际代码和测试diff的银行质量、安全及兼容风险，并核对已有扫描报告；不代替人工批准。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取最终 diff、Spec、不变项、范围、规范、测试计划与实际结果，不仅阅读开发者摘要。
2. 确认候选快照与当前文件一致，新增、删除、重命名及未跟踪文件均纳入。
3. 逐 hunk 检查需求对应性、异常路径、并发、状态变化、事务和数据安全；只对有依据问题给结论。
4. 单独审查测试 diff：断言是否弱化、用例是否删除/跳过、expected 是否依赖实现、Mock 是否越界。
5. 导入扫描结果并区分新增/既存告警；基线不一致则不能做可靠差分。
6. 输出含文件/符号/证据、风险、建议与复核方式的发现；高风险项交人审，AI结论不能等同批准。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类ReviewEvidenceCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`quality-review.json/md`；findings[{id,severity,path,symbol,evidence,reason,recommendation,verification}]、scan_runs[]、test_integrity_findings[]、unreviewed[]。零发现只能表述“已审查范围未发现问题”。

使用[业务模板](templates/quality-review.json)与[输出结构](schemas/quality-review.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需严重级别、扫描器/豁免机制、职责分离与人审范围。必需扫描缺失或关键发现未关闭时不能在 S20 声明可合并。

## 按需参考

- [bank-review-checklist](references/bank-review-checklist.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
