import org.json.*;
public final class ReviewEvidenceCheck{
 public static void main(String[] a){Support.mainEntry(a,"S17",s->{
  JSONObject p=Support.payload(s.artifact("artifact","quality_review"));JSONArray findings=p.getJSONArray("findings");s.ids(findings,"id","REVIEW_ID");s.evidenceRows(findings,"evidence");
  for(Object x:findings){JSONObject f=(JSONObject)x;Support.requireFields(s,f,"path","symbol","reason","recommendation","verification","severity");s.file(f.getString("path"));
   if(f.optBoolean("blocking")&&!f.optBoolean("closed"))s.block("QUALITY_BLOCKER","Unresolved blocking quality finding");}
  for(Object x:p.getJSONArray("scan_runs")){JSONObject r=(JSONObject)x;Support.requireFields(s,r,"tool","version","report_path","report_sha256","snapshot_digest");
   String reportPath=r.getString("report_path"),hash=Support.sha(s.file(reportPath));s.inputHashes.put(reportPath,hash);
   s.check("SCAN_REPORT_CURRENT",hash.equals(r.getString("report_sha256")),"Scanner report hash");
   s.check("SCAN_SNAPSHOT",r.getString("snapshot_digest").equals(p.getString("candidate_snapshot")),"Scan matches candidate");
   s.check("SCAN_EXECUTED","EXECUTED".equals(r.optString("state")),"Required scanner actually ran");}
  if(Support.arr(p,"unreviewed").length()>0)s.unknown("REVIEW_INCOMPLETE","Unreviewed scope remains");
  s.check("TEST_DIFF_REVIEWED",Support.present(p,"test_diff_review_ref"),"Test modifications were reviewed separately");
  s.facts.put("candidate_digest",p.getString("candidate_snapshot"));
 });}
}
