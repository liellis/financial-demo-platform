# S17 派生记录

- [skills/requesting-code-review/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/requesting-code-review/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [templates/commands/analyze.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/analyze.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。

- S17-D01：删除必须派 reviewer 子 Agent 的指令，新增基线/候选快照和实际 diff 清单。
- S17-D02：新增银行质量清单：金额/日期、事务/重试、SQL、资源、异常、敏感日志、权限、兼容与测试完整性。
- S17-D03：导入客户已有扫描报告，核对工具版本及快照；未运行不能写零告警。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
