# bank-review-checklist

逐hunk对应AC及范围，审异常/并发/事务/金额/日期/SQL/权限/日志/兼容和部署影响，不只读作者摘要。发现附位置、证据、风险、建议和验证方法。

测试diff单审：Oracle来源、expected是否调用实现、替身是否Mock subject、断言/用例删除和跳过。扫描须有实际工具/版本/报告hash及候选快照，缺报告不填0告警。关键reviewer审批不能由AI代替。
