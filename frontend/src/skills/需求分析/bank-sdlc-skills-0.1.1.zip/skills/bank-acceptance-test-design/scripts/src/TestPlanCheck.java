import org.json.*;import java.util.*;
public final class TestPlanCheck{
 public static void main(String[] a){Support.mainEntry(a,"S15",s->{
  JSONObject p=Support.payload(s.artifact("artifact")),sp=Support.payload(s.artifact("spec"));JSONArray cases=p.getJSONArray("cases");
  s.ids(cases,"case_id","CASE_ID");Set<String> ac=s.ids(sp.getJSONArray("acceptance_criteria"),"ac_id","AC_ID");s.refs(cases,"ac_ids",ac,"CASE_AC");
  Set<String> covered=new HashSet<String>();
  for(Object x:cases){JSONObject c=(JSONObject)x;Support.requireFields(s,c,"inputs","action","expected","oracle_ref","environment","cleanup");
   s.check("TEST_CRITICALITY",c.opt("critical") instanceof Boolean,"Test criticality is explicitly classified");
   s.check("TEST_LEVEL",Arrays.asList("UNIT","COMPONENT","INTEGRATION","CONTRACT","NONFUNCTIONAL").contains(c.getString("level")),"Explicit test level");
   s.check("INDEPENDENT_ORACLE",c.optBoolean("oracle_independent")&&!c.optBoolean("mocks_subject"),"Expected result does not call/mock subject logic");
   if(c.optBoolean("critical")&&!Support.present(c,"review_ref"))s.confirm("CRITICAL_TEST_REVIEW","Critical test requires independent business/QA review");
   covered.addAll(Support.strings(c.getJSONArray("ac_ids")));
  }
  s.check("PLAN_AC_COVERAGE",covered.containsAll(ac),"Every AC has a designed test case");s.facts.put("case_count",cases.length());
 });}
}
