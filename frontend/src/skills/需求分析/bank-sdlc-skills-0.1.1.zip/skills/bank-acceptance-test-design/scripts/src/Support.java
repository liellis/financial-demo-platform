import org.json.*;
import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.security.*;
import java.time.*;
import java.util.*;
import java.util.regex.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

/** Local file/contract primitives only. No model calls, workflow dispatch or network client. */
public final class Support {
    public static final int MAX_JSON = 2 * 1024 * 1024;
    public final Path root;
    public final JSONObject request;
    public final JSONArray checks = new JSONArray(), unknowns = new JSONArray();
    public final JSONObject facts = new JSONObject(), inputHashes = new JSONObject();
    private String changeId;
    private String status = "PASS";
    public interface Work { void run(Support s) throws Exception; }
    private Support(Path r, JSONObject q) { root=r; request=q; }
    public static void mainEntry(String[] args, String skill, Work work) {
        JSONObject result = new JSONObject();
        int code=4;
        try {
            Map<String,String> flags=new LinkedHashMap<String,String>();
            for(int i=0;i<args.length;i+=2) {
                if(i+1>=args.length || !Arrays.asList("--project-root","--input","--output").contains(args[i])
                    || flags.put(args[i],args[i+1])!=null) throw new IOException("Invalid arguments");
            }
            if(flags.size()!=3) throw new IOException("Require --project-root --input --output");
            Path root=Paths.get(flags.get("--project-root")).toRealPath();
            if(!Files.isDirectory(root)) throw new IOException("Project root is not a directory");
            Path in=inside(root,flags.get("--input"),true);
            Path out=inside(root,flags.get("--output"),false);
            Path outputRoot=root.resolve(".sdlc");
            if(!out.startsWith(outputRoot) || out.equals(in)) throw new IOException("Output must be a new .sdlc file");
            if(Files.exists(out,LinkOption.NOFOLLOW_LINKS)) throw new IOException("Output exists; use a new revision");
            JSONObject q=readJson(in);
            Support s=new Support(root,q);
            s.inputHashes.put(root.relativize(in).toString(),sha(in));
            if(present(q,"change_id")) s.bindChange(q.getString("change_id"));
            work.run(s);
            result.put("schema_version","2.0").put("skill_id",skill).put("status",s.status)
                .put("verification_scope","STRUCTURE_AND_LOCAL_EVIDENCE")
                .put("created_at",OffsetDateTime.now().toString()).put("checks",s.checks)
                .put("unknowns",s.unknowns).put("input_hashes",s.inputHashes).put("facts",s.facts);
            if(s.changeId!=null) result.put("change_id",s.changeId);
            atomicNew(out,result.toString(2)+"\n");
            code=s.status.equals("PASS")?0:2;
        } catch(Exception e) {
            result=new JSONObject().put("status","BLOCKED").put("error_code","INPUT_OR_EXECUTION_ERROR")
                .put("skill_id",skill).put("message",safeError(e));
        }
        System.out.println(result.toString(2));
        System.exit(code);
    }
    static String safeError(Exception e) {
        // Exception messages may contain source text, secrets or command output.
        if(e instanceof SAXException) return "XML rejected or malformed";
        if(e instanceof JSONException) return "JSON rejected or malformed";
        return e.getClass().getSimpleName()+": input/path/operation rejected; inspect local configuration";
    }
    public void check(String id, boolean ok, String message) {
        checks.put(new JSONObject().put("rule_id",id).put("result",ok?"PASS":"FAIL").put("message",message));
        if(!ok && !status.equals("BLOCKED")) status="FAIL";
    }
    public boolean passed() { return status.equals("PASS"); }
    public void block(String id, String message) {
        checks.put(new JSONObject().put("rule_id",id).put("result","BLOCKED").put("message",message)); status="BLOCKED";
    }
    public void unknown(String id,String message) {
        unknowns.put(new JSONObject().put("id",id).put("reason",message));
        if(status.equals("PASS")) status="UNKNOWN";
    }
    public void confirm(String id,String message) {
        checks.put(new JSONObject().put("rule_id",id).put("result","NEEDS_CONFIRMATION").put("message",message));
        if(status.equals("PASS") || status.equals("UNKNOWN")) status="NEEDS_CONFIRMATION";
    }
    public Path file(String p) throws IOException { return inside(root,p,true); }
    public JSONObject json(String p) throws Exception {
        Path f=file(p); inputHashes.put(p,sha(f)); return readJson(f);
    }
    public JSONObject artifact(String field) throws Exception {
        String p=request.getString(field); JSONObject a=json(p);
        check("ARTIFACT_TYPE",present(a,"artifact_type") && present(a,"artifact_id") && present(a,"change_id"),"Artifact has type, change and stable ID");
        check("ARTIFACT_VERSION","2.0".equals(a.optString("schema_version")),"Contract version is 2.0");
        check("ARTIFACT_CURRENT",!Arrays.asList("STALE","BLOCKED","FAIL").contains(a.optString("status")),"Artifact is usable");
        check("ARTIFACT_STATUS",Arrays.asList("PASS","FAIL","BLOCKED","UNKNOWN","NEEDS_CONFIRMATION","STALE").contains(a.optString("status")),"Artifact status is defined");
        bindChange(a.getString("change_id"));
        if(a.optString("status").equals("UNKNOWN")) unknown("UPSTREAM_UNKNOWN","Upstream evidence remains unknown");
        if(a.optString("status").equals("NEEDS_CONFIRMATION")) confirm("UPSTREAM_CONFIRMATION","Upstream evidence needs confirmation");
        if(field.equals("artifact")) facts.put("artifact_path",p).put("artifact_sha256",sha(file(p))).put("source_snapshot",a.opt("source_snapshot"));
        return a;
    }
    public JSONObject artifact(String field,String type) throws Exception {
        JSONObject a=artifact(field);
        check("ARTIFACT_EXPECTED_TYPE",type.equals(a.optString("artifact_type")),"Expected artifact type: "+type);
        check("ARTIFACT_PASS","PASS".equals(a.optString("status")),"Required artifact is PASS");
        return a;
    }
    public void bindChange(String id) throws IOException {
        if(id==null||!id.matches("[A-Za-z0-9][A-Za-z0-9-]{0,63}")) throw new IOException("Invalid change identity");
        if(changeId==null)changeId=id;
        check("CHANGE_ID",changeId.equals(id),"All evidence belongs to the same change");
    }
    public String changeId() { return changeId; }
    public static JSONObject payload(JSONObject a) { return a.has("payload")?a.getJSONObject("payload"):a; }
    public static JSONArray arr(JSONObject o,String k) { return o.optJSONArray(k)==null?new JSONArray():o.getJSONArray(k); }
    public static boolean present(JSONObject o,String k) {
        return o.has(k) && !o.isNull(k) && (!(o.get(k) instanceof String) || !o.getString(k).trim().isEmpty());
    }
    public static Set<String> strings(JSONArray a) {
        Set<String> r=new LinkedHashSet<String>(); for(Object x:a) r.add(String.valueOf(x)); return r;
    }
    public static JSONArray stringArray(JSONObject o,String key) {
        Object value=o.get(key);
        if(!(value instanceof JSONArray))throw new JSONException("Expected string array");
        JSONArray a=(JSONArray)value;
        for(Object x:a)if(!(x instanceof String)||((String)x).trim().isEmpty())throw new JSONException("Expected nonempty string");
        if(strings(a).size()!=a.length())throw new JSONException("Duplicate array item");
        return a;
    }
    public Set<String> ids(JSONArray a,String key,String rule) {
        Set<String> r=new LinkedHashSet<String>();
        for(Object x:a) {
            JSONObject o=(JSONObject)x; String id=o.optString(key,"");
            check(rule,!id.isEmpty() && r.add(id),"IDs must be nonempty and unique");
        }
        return r;
    }
    public void refs(JSONArray rows,String field,Set<String> targets,String rule) {
        for(Object x:rows) for(Object ref:arr((JSONObject)x,field))
            check(rule,targets.contains(String.valueOf(ref)),"Referenced ID exists: "+String.valueOf(ref));
    }
    public boolean evidence(JSONObject e) throws Exception {
        if(!present(e,"path") || !present(e,"sha256")) return false;
        Path p=file(e.getString("path"));
        boolean ok=sha(p).equals(e.getString("sha256"));
        if(e.has("line_start") || e.has("line_end")) {
            int start=e.optInt("line_start",0), end=e.optInt("line_end",0);
            long lines;
            try(java.util.stream.Stream<String> stream=Files.lines(p,StandardCharsets.UTF_8)) { lines=stream.count(); }
            ok &= start>=1 && end>=start && end<=lines;
        }
        return ok;
    }
    public void evidenceRows(JSONArray rows,String field) throws Exception {
        for(Object x:rows) {
            JSONArray es=arr((JSONObject)x,field);
            check("EVIDENCE_PRESENT",es.length()>0,"Every claimed fact needs source evidence");
            for(Object e:es) check("EVIDENCE_CURRENT",evidence((JSONObject)e),"Evidence file hash and location match");
        }
    }
    public static Path inside(Path root,String name,boolean mustExist) throws IOException {
        if(name.indexOf('\0')>=0) throw new IOException("NUL");
        Path p=Paths.get(name);
        if(!p.isAbsolute()) p=root.resolve(p);
        p=p.normalize().toAbsolutePath();
        if(!p.startsWith(root)) throw new IOException("Outside root");
        Path cursor=p;
        while(cursor!=null && !Files.exists(cursor,LinkOption.NOFOLLOW_LINKS)) cursor=cursor.getParent();
        if(cursor==null || !cursor.toRealPath().startsWith(root)) throw new IOException("Symlink escape");
        // Reject symlinks even when they point back into root: stable evidence must have an unambiguous owner.
        Path rel=root.relativize(p), walk=root;
        for(Path part:rel) {
            walk=walk.resolve(part);
            if(Files.isSymbolicLink(walk)) throw new IOException("Symlinks are not accepted");
        }
        if(mustExist && (!Files.isRegularFile(p) || Files.isSymbolicLink(p))) throw new IOException("Missing regular file");
        return p;
    }
    public static JSONObject readJson(Path p) throws Exception {
        byte[] b=bounded(p,MAX_JSON);
        String t=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(b)).toString();
        int depth=0;boolean quoted=false,escape=false;
        for(int i=0;i<t.length();i++) {char c=t.charAt(i);
            if(quoted) {if(escape)escape=false;else if(c=='\\')escape=true;else if(c=='"')quoted=false;}
            else if(c=='"')quoted=true;else if(c=='{'||c=='[') {if(++depth>64)throw new JSONException("Nesting budget");}
            else if(c=='}'||c==']')depth--;
        }
        JSONParserConfiguration config=new JSONParserConfiguration().withStrictMode(true)
            .withOverwriteDuplicateKey(false).withMaxNestingDepth(64);
        JSONTokener tok=new JSONTokener(t,config);
        JSONObject obj=new JSONObject(tok);
        if(tok.nextClean()!=0) throw new JSONException("Trailing input");
        return obj;
    }
    public static byte[] bounded(Path p,int max) throws IOException {
        if(Files.size(p)>max) throw new IOException("Input too large");
        try(InputStream in=Files.newInputStream(p); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))!=-1) { if(out.size()+n>max) throw new IOException("Input too large");out.write(buf,0,n); }
            return out.toByteArray();
        }
    }
    public static String sha(Path p) throws Exception { return sha(bounded(p,32*1024*1024)); }
    public static String sha(byte[] bytes) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes); StringBuilder b=new StringBuilder();
        for(byte x:digest) b.append(String.format("%02x",x & 255)); return b.toString();
    }
    public static void atomicNew(Path p,String data) throws IOException {
        Files.createDirectories(p.getParent());
        Path realParent=p.getParent().toRealPath();
        if(!realParent.equals(p.getParent().toAbsolutePath().normalize())) throw new IOException("Output parent changed");
        Path temp=Files.createTempFile(realParent,".bank-skill-",".tmp");
        try {
            Files.write(temp,data.getBytes(StandardCharsets.UTF_8));
            // No REPLACE_EXISTING. Do not overwrite evidence from another run.
            Files.createLink(p,temp);
        } finally { Files.deleteIfExists(temp); }
    }
    public static Document xml(Path p) throws Exception {
        byte[] bytes=bounded(p,8*1024*1024);
        DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();
        f.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING,true);
        f.setAttribute("http://www.oracle.com/xml/jaxp/properties/maxElementDepth","128");
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        f.setFeature("http://xml.org/sax/features/external-general-entities",false);
        f.setFeature("http://xml.org/sax/features/external-parameter-entities",false);
        f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
        f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD,"");
        f.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA,"");
        f.setXIncludeAware(false); f.setExpandEntityReferences(false);
        DocumentBuilder b=f.newDocumentBuilder();
        b.setErrorHandler(new ErrorHandler(){
            public void warning(SAXParseException e)throws SAXException{throw e;}
            public void error(SAXParseException e)throws SAXException{throw e;}
            public void fatalError(SAXParseException e)throws SAXException{throw e;}
        });
        return b.parse(new ByteArrayInputStream(bytes));
    }
    public static List<Element> elements(Element e,String name) {
        List<Element> r=new ArrayList<Element>(); NodeList ns=e.getElementsByTagName(name);
        for(int i=0;i<ns.getLength();i++) r.add((Element)ns.item(i)); return r;
    }
    public static String childText(Element e,String name) {
        for(Node n=e.getFirstChild();n!=null;n=n.getNextSibling())
            if(n instanceof Element && ((Element)n).getTagName().equals(name)) return n.getTextContent().trim();
        return "";
    }
    public static boolean glob(String value,String pattern) {
        if(pattern.indexOf('\\')>=0 || pattern.startsWith("/") || pattern.contains("..")) return false;
        StringBuilder r=new StringBuilder("^");
        for(int i=0;i<pattern.length();i++){
            char c=pattern.charAt(i);
            if(c=='*') {
                if(i+1<pattern.length() && pattern.charAt(i+1)=='*') {
                    i++; if(i+1<pattern.length() && pattern.charAt(i+1)=='/') {i++;r.append("(?:.*/)?");}
                    else r.append(".*");
                } else r.append("[^/]*");
            } else if(c=='?') r.append("[^/]");
            else r.append(Pattern.quote(String.valueOf(c)));
        }
        return value.replace('\\','/').matches(r.append("$").toString());
    }
    public static boolean anyGlob(String path,JSONArray patterns) {
        for(Object g:patterns) if(glob(path,String.valueOf(g))) return true; return false;
    }
    public static boolean anyGlobAny(JSONArray paths,String pattern) {
        for(Object p:paths) if(glob(String.valueOf(p),pattern)) return true; return false;
    }
    public JSONObject snapshot(JSONArray paths) throws Exception {
        TreeMap<String,String> sorted=new TreeMap<String,String>();
        for(Object p:paths) {
            String key=String.valueOf(p).replace('\\','/');
            if(key.startsWith(".sdlc/") || key.startsWith(".git/") || key.startsWith(".opencode/"))
                throw new IOException("Runtime/governance files not in source snapshot");
            sorted.put(key,sha(file(key)));
        }
        JSONObject files=new JSONObject(sorted);
        StringBuilder canonical=new StringBuilder();
        for(Map.Entry<String,String> e:sorted.entrySet()) canonical.append(e.getKey()).append('\0').append(e.getValue()).append('\n');
        return new JSONObject().put("files",files).put("digest",sha(canonical.toString().getBytes(StandardCharsets.UTF_8)));
    }
    public boolean currentSnapshot(JSONObject snap) throws Exception {
        JSONObject files=snap.getJSONObject("files");
        if(files.length()==0) return false;
        JSONObject now=snapshot(new JSONArray(new TreeSet<String>(files.keySet())));
        return now.getString("digest").equals(snap.getString("digest")) && now.getJSONObject("files").similar(files);
    }
    public static boolean confirmed(JSONObject o) {
        return present(o,"confirmation_ref") && "CONFIRMED".equals(o.optString("status"));
    }
    public static void requireFields(Support s,JSONObject o,String... fields) {
        for(String f:fields) s.check("REQUIRED_"+f,present(o,f),"Required field: "+f);
    }
}

