# S15 派生记录

- [skills/test-driven-development/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/test-driven-development/writing-good-tests.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/writing-good-tests.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S15-D01：把通用示例改为项目现有 JUnit/Mockito 版本，不默认升级 JUnit5。
- S15-D02：新增 AC→case→Oracle 的显式映射和测试层级选择；区分单元、组件、集成、契约及非功能验证。
- S15-D03：新增银行边界矩阵；拒绝“只覆盖正常路径”和用实现本身计算 expected。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
