---
name: bank-acceptance-test-design
description: 验收测试设计；把确认AC转成正常、边界、异常测试设计，明确独立Oracle、测试层级、数据和环境。
metadata:
  skill-id: "S15"
  version: "0.1.1"
---

# 验收测试设计

把确认AC转成正常、边界、异常测试设计，明确独立Oracle、测试层级、数据和环境。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取确认 Spec、S03 规则、S05 影响、S13规范和项目测试能力。
2. 每条 AC 建正常、边界、异常用例；不适用项写理由，不套用所有场景。
3. 金额明确单位、精度、舍入与合成样例；日期明确日历和截止边界；幂等设计重复、乱序、超时后重试。
4. 选择最低但足够真实的层级：事务/SQL方言/锁需客户数据库环境验证，Mock 仅隔离真正外部依赖。
5. 明确 arrange、action、assert、Oracle 来源、清理策略、预期失败方式及所需数据。
6. 关键业务用例交独立业务/QA确认；无确认先生成设计草案，不将模型建议变成事实。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类TestPlanCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`test-plan.json/md`；cases[{case_id,ac_ids,level,inputs,action,expected,oracle_ref,environment,cleanup,review_ref}]、not_automated[]。S24生成目标测试，S19选择关联回归。

使用[业务模板](templates/test-plan.json)与[输出结构](schemas/test-plan.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需测试框架、脱敏/合成数据、业务基准样例、数据库及关键用例 reviewer。Oracle 未确认或必需环境不存在时标阻塞。

## 按需参考

- [bank-test-cases](references/bank-test-cases.md)：对应步骤判断。
- [test-double-policy](references/test-double-policy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

交S24前确认计划payload的confirmation及spec_sha256，并为目标case记录test_ids、critical和Oracle；模板保留未确认状态，不由模型代签。
