---
name: bank-legacy-characterization
description: 存量行为保护；在修改前为影响范围内应保持行为建立保护基线，区分目标变化和已知缺陷，并比较新增失败。
metadata:
  skill-id: "S23"
  version: "0.1.1"
---

# 存量行为保护

在修改前为影响范围内应保持行为建立保护基线，区分目标变化和已知缺陷，并比较新增失败。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 S03、Spec 的不变项、影响点和当前测试；确认源码基线及客户已有修改。
2. 选择影响边界内代表性行为，包括正常、异常、副作用和协议兼容；不追求无边界补全覆盖。
3. 对规则未确认的行为只记录观察结果；已知缺陷单列，不能把缺陷数值写入业务 Oracle。
4. 编写保护测试，固定时钟、随机种子和合成数据；仅 Mock 外部依赖，不替换被测逻辑。
5. 按 S16 方法在未改目标生产逻辑的基线上执行；记录通过、既存失败与不稳定。
6. 将保护集、基线 run 和排除项交 S24/S25，后续每次实现验证比较新增失败。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类BaselineDiff。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

保护测试代码、`characterization.json/md`；preserve_cases[]、target_change_cases[]、known_defects[]、baseline_run_ref、existing_failures[]、flaky_cases[]。仅有观察截图不能当自动保护测试。

使用[业务模板](templates/characterization.json)与[输出结构](schemas/characterization.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需关键历史样例、合法合成数据及旧系统行为确认人。基线不能运行时先报告工程恢复任务，不能标“保护已建立”。

## 按需参考

- [characterization-policy](references/characterization-policy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
