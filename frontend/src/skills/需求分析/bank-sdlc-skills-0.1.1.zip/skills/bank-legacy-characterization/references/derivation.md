# S23 派生记录

- [skills/test-driven-development/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/test-driven-development/writing-good-tests.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/writing-good-tests.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/systematic-debugging/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/systematic-debugging/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S23-D01：新增三类现状：应保持行为、本次目标变化、已知缺陷/待确认；后两类不能直接固化为通过标准。
- S23-D02：新增确定性测试隔离：时钟、随机值、外部系统用受控替身；数据库行为使用客户实际验证环境。
- S23-D03：新增保护基线与既存失败清单；禁止以“早已失败”掩盖本次新增回归。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
