# 存量行为保护

状态：NEEDS_CONFIRMATION

来源ID与摘要：

保护测试代码、`characterization.json/md`；preserve_cases[]、target_change_cases[]、known_defects[]、baseline_run_ref、existing_failures[]、flaky_cases[]。仅有观察截图不能当自动保护测试。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
