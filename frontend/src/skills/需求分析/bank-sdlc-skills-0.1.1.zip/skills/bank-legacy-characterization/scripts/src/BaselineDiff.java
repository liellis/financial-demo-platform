import org.json.*;import java.util.*;
public final class BaselineDiff{
 public static void main(String[] a){Support.mainEntry(a,"S23",s->{
  JSONObject base=RunEvidence.load(s,s.request.getString("baseline_run"),false),candidate=RunEvidence.load(s,s.request.getString("candidate_run"),true);
  Map<String,JSONObject> b=RunEvidence.cases(base),c=RunEvidence.cases(candidate);JSONArray old=new JSONArray(),introduced=new JSONArray();
  JSONArray protectedIds=s.request.getJSONArray("protected_test_ids");s.check("PROTECTION_NONEMPTY",protectedIds.length()>0,"Protected behavior set is explicit");
  for(Object id:protectedIds){String key=id.toString();JSONObject before=b.get(key),after=c.get(key);
   s.check("PROTECTION_EXISTS",before!=null&&after!=null,"Protected case is present in both runs: "+key);
   if(before==null||after==null)continue;
   String bs=before.getString("status"),cs=after.getString("status");
   if(!bs.equals("PASSED"))old.put(key);
   if(bs.equals("PASSED")&&!cs.equals("PASSED"))introduced.put(key);
   if(!bs.equals("PASSED")&&!bs.equals(cs))introduced.put(key+"::CHANGED_FAILURE_STATE");
  }
  s.check("NO_NEW_REGRESSION",introduced.length()==0,"No introduced protection failure");
  if(old.length()>0)s.unknown("EXISTING_FAILURES","Existing failures remain visible and are not successful protection evidence");
  s.facts.put("existing_failures",old).put("introduced_failures",introduced).put("flaky",base.optBoolean("flaky")||candidate.optBoolean("flaky"))
   .put("baseline_run",s.request.getString("baseline_run")).put("candidate_run",s.request.getString("candidate_run"))
   .put("protected_test_ids",protectedIds).put("candidate_digest",candidate.getJSONObject("after_snapshot").getString("digest"));
  s.check("PROTECTION_STABLE",!base.optBoolean("flaky")&&!candidate.optBoolean("flaky"),"Protection is not a rerun hiding an earlier failure");
 });}
}
