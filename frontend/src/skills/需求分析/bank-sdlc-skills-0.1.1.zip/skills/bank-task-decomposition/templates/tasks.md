# 任务拆解

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`tasks.json/md`；tasks[{id,ac_ids,files,depends_on,actions,verification,done_evidence,stop_conditions}]。任务“完成”只能由证据更新，不能凭勾选决定。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
