import org.json.*;import java.util.*;
public final class TaskCheck{
 public static void main(String[] a){Support.mainEntry(a,"S11",s->{
  JSONObject p=Support.payload(s.artifact("artifact")),sp=Support.payload(s.artifact("spec"));JSONArray tasks=p.getJSONArray("tasks");
  s.check("TASKS_PRESENT",tasks.length()>0&&tasks.length()<=1000,"Bounded nonempty task list");
  Set<String> ids=s.ids(tasks,"id","TASK_ID"),acs=s.ids(sp.getJSONArray("acceptance_criteria"),"ac_id","AC_ID");s.refs(tasks,"ac_ids",acs,"TASK_AC");
  Map<String,Integer> degree=new HashMap<String,Integer>();Map<String,List<String>> next=new HashMap<String,List<String>>();Set<String> verified=new HashSet<String>();
  for(String id:ids){degree.put(id,0);next.put(id,new ArrayList<String>());}
  for(Object x:tasks){JSONObject t=(JSONObject)x;Support.requireFields(s,t,"actions","verification","files","done_evidence");
   for(Object ref:t.getJSONArray("depends_on")){String d=ref.toString();s.check("TASK_DEPENDENCY",ids.contains(d),"Dependency exists");
    if(ids.contains(d)){degree.put(t.getString("id"),degree.get(t.getString("id"))+1);next.get(d).add(t.getString("id"));}}
   if(t.optString("kind").equals("VERIFY"))verified.addAll(Support.strings(t.getJSONArray("ac_ids")));
   s.check("NO_AUTOMATIC_L3",!t.optString("risk_level").equals("L3")||!t.optBoolean("automatic_production_write"),"Risk cannot be downgraded by task slicing");
  }
  ArrayDeque<String> q=new ArrayDeque<String>();for(String id:ids)if(degree.get(id)==0)q.add(id);JSONArray order=new JSONArray();
  while(!q.isEmpty()){String id=q.remove();order.put(id);for(String n:next.get(id)){degree.put(n,degree.get(n)-1);if(degree.get(n)==0)q.add(n);}}
  s.check("TASK_DAG",order.length()==ids.size(),"Task dependency graph is acyclic");
  s.check("AC_VERIFICATION_TASK",verified.containsAll(acs),"Every AC has a verification task");s.facts.put("topological_order",order);
 });}
}
