---
name: bank-task-decomposition
description: 任务拆解；将确认规格拆成带准确文件、依赖、测试和完成证据的小任务；不启动执行或自动提交。
metadata:
  skill-id: "S11"
  version: "0.1.1"
---

# 任务拆解

将确认规格拆成带准确文件、依赖、测试和完成证据的小任务；不启动执行或自动提交。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取已确认 Spec、S10、风险和范围；关键阻塞未关闭时只出草案。
2. 按行为切片而不是简单按文件拆，先建立既存保护和目标测试，再实现，再回归/审查。
3. 每项指定 task_id、AC、准确文件/符号、输入、修改类型与预期输出。
4. 给出可执行验证：项目批准命令 ID、目标测试或应产生的工件；不得填写猜测成功结果。
5. 建立依赖图，循环或缺项由 TaskCheck 阻断；关键验证必须是完成路径上的必要节点。
6. 标明可以并行的只读活动与共享文件冲突；默认同一宿主串行执行，不隐式派发代理。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类TaskCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`tasks.json/md`；tasks[{id,ac_ids,files,depends_on,actions,verification,done_evidence,stop_conditions}]。任务“完成”只能由证据更新，不能凭勾选决定。

使用[业务模板](templates/tasks.json)与[输出结构](schemas/tasks.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需职责、测试层级、允许自动执行阶段及现有工单字段。数据库/权限/L3任务必须含人工节点；不得拆小后规避原风险等级。

## 按需参考

- [task-sizing](references/task-sizing.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
