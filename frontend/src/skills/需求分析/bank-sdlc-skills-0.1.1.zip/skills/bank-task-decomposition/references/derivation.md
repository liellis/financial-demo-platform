# S11 派生记录

- [templates/commands/tasks.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/tasks.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。
- [skills/writing-plans/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/writing-plans/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S11-D01：删除上游强制工具、提交和子 Agent 指令；将“测试可选”改为适用变更须测试先行或具有客户批准的替代验证。
- S11-D02：新增先决条件、AC、允许路径、完成证据、风险和停机条件。
- S11-D03：新增任务 DAG 校验及验证任务必达检查；禁止只有“改完代码”任务而无运行验证。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
