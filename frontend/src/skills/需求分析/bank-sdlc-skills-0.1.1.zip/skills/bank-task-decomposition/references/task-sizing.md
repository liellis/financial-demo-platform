# task-sizing

每task包括id、ac_ids、depends_on、files、actions、verification、done_evidence、stop_conditions。按行为拆：保护→目标测试→有效Red→最小实现→目标/保护/回归→审查。

VERIFY任务覆盖所有有效AC，依赖为DAG，完成以真实工件为准。风险继承到子任务，不能拆成小任务绕L3。共享文件默认串行，不隐式派Agent或提交。
