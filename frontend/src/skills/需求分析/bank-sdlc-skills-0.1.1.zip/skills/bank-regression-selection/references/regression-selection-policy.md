# regression-selection-policy

并集直接测试、影响模块、客户强制集及可信PER_TEST_SYMBOL映射；映射需源快照和测试ID，聚合JaCoCo不是单测映射。

未知调用/反射/公共组件/配置变化时扩大模块或全套，映射过期同样fallback。每个选择写reason/evidence，预算超限人工裁决不删强制集，不虚构最小充分性或耗时。
