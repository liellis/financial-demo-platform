# S19 派生记录

- [skills/verification-before-completion/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/verification-before-completion/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S19-D01：建立按直接符号、影响模块、客户关键测试集和可用动态映射的集合并集规则。
- S19-D02：支持客户现有 coverage/测试映射导入；普通 JaCoCo 聚合 XML 不能伪称 test→symbol 映射。
- S19-D03：未知依赖或映射过期时扩大到模块/关键集/全套，不能因找不到映射选零用例。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
