---
name: bank-regression-selection
description: 回归测试选择；依据直接影响、模块、强制集和可信单测映射保守选择回归；未知覆盖扩大范围而非选择零测试。
metadata:
  skill-id: "S19"
  version: "0.1.1"
---

# 回归测试选择

依据直接影响、模块、强制集和可信单测映射保守选择回归；未知覆盖扩大范围而非选择零测试。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 diff、S05影响、调用链边界、客户回归策略和测试目录。
2. 选择直接变更测试及 S23保护集；加入受影响接口/模块的确定测试。
3. 如有按单测采集的覆盖映射，核对版本、采集粒度和测试 ID；不匹配则不用于缩减。
4. 加入客户必须的账务/支付/批量/契约回归集，不能被算法剔除。
5. 对未知反向调用、反射、公共组件或大范围配置变化按批准策略扩大；成本超预算转人决定。
6. 输出选择原因、未选理由、所需环境、预算及残余风险，再交 S16运行。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类RegressionSelect。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`regression-plan.json/md`；selected[{test_id,reason,evidence}]、mandatory_suites[]、unknown_coverage[]、expansion_decision、not_selected[]、estimated_cost_source。没有历史耗时就不虚构分钟数。

使用[业务模板](templates/regression-plan.json)与[输出结构](schemas/regression-plan.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需关键回归集、窗口、成本上限、集成环境及人工裁决流程。不能为满足运行预算自动删除关键测试。

## 按需参考

- [regression-selection-policy](references/regression-selection-policy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
