# 回归测试选择

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`regression-plan.json/md`；selected[{test_id,reason,evidence}]、mandatory_suites[]、unknown_coverage[]、expansion_decision、not_selected[]、estimated_cost_source。没有历史耗时就不虚构分钟数。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
