import org.json.*;import java.util.*;
public final class RegressionSelect{
 public static void main(String[] a){Support.mainEntry(a,"S19",s->{
  JSONObject p=s.request;s.bindChange(p.getString("change_id"));LinkedHashMap<String,Set<String>> chosen=new LinkedHashMap<String,Set<String>>();
  for(String field:Arrays.asList("direct_tests","module_tests","mandatory_tests"))for(Object t:p.getJSONArray(field)){
   String id=t.toString();if(!chosen.containsKey(id))chosen.put(id,new LinkedHashSet<String>());chosen.get(id).add(field);}
  boolean unknown=p.optBoolean("unknown_dependencies");boolean mapped=false;
  if(Support.present(p,"coverage_map")){
   JSONObject m=s.json(p.getString("coverage_map"));
   if(!m.optString("format").equals("PER_TEST_SYMBOL")||!m.optString("snapshot_digest").equals(p.getString("snapshot_digest"))){
    unknown=true;s.unknown("COVERAGE_UNUSABLE","Aggregated/stale coverage cannot reduce regression scope");
   }else{mapped=true;Set<String> syms=Support.strings(p.getJSONArray("changed_symbols"));
    for(Object x:m.getJSONArray("rows")){JSONObject row=(JSONObject)x;Set<String> hit=Support.strings(row.getJSONArray("symbols"));hit.retainAll(syms);
     if(!hit.isEmpty()){String id=row.getString("test_id");if(!chosen.containsKey(id))chosen.put(id,new LinkedHashSet<String>());chosen.get(id).add("per_test_mapping");}}}
  }else unknown=true;
  if(unknown){
   JSONArray fallback=p.getJSONArray("fallback_tests");
   if(fallback.length()==0)s.block("REGRESSION_FALLBACK","Unknown coverage requires a configured module/full/critical fallback");
   for(Object t:fallback){String id=t.toString();if(!chosen.containsKey(id))chosen.put(id,new LinkedHashSet<String>());chosen.get(id).add("conservative_fallback");}
  }
  JSONArray result=new JSONArray();for(Map.Entry<String,Set<String>> e:chosen.entrySet())result.put(new JSONObject().put("test_id",e.getKey()).put("reasons",new JSONArray(e.getValue())));
  s.check("REGRESSION_NONEMPTY",result.length()>0,"Regression selection is not empty");
  if(result.length()>p.getInt("max_tests"))s.confirm("REGRESSION_BUDGET","Selection exceeds customer budget; mandatory cases were not removed");
  s.facts.put("selected",result).put("expanded",unknown).put("precise_mapping_used",mapped).put("completeness_proven",false).put("candidate_digest",p.getString("snapshot_digest"));
 });}
}
