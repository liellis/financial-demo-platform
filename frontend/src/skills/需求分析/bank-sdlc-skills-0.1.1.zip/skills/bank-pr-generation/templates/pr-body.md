# PR 生成

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`review/pr-title.txt`、`review/pr-body.md`、`pr-draft.json`；source_snapshot、target_branch、review_manifest_ref、external_action、authorization_ref、pr_url。未创建时 pr_url=null。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
