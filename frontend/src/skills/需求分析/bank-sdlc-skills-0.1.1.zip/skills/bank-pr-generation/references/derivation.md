# S21 派生记录

- [skills/finishing-a-development-branch/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/finishing-a-development-branch/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S21-D01：删掉默认 push、merge、删分支和 worktree 清理；将这些动作从方法默认路径移出。
- S21-D02：新增标题/描述模板与工单、Spec、风险、测试证据链接；草稿与正式创建状态分开。
- S21-D03：可选对接客户现有 Git CLI/API，由显式授权触发；不自建凭据管理和常驻服务。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
