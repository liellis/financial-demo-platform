# git-provider-boundaries

默认产生本地title/body/checklist，说明具体问题、行为、实际验证、限制与工单/证据引用；远端reviewer不能访问本机绝对路径，改为仓内或受控链接。

push/创建PR仅在已有明确授权且客户权限允许时执行，失败查重避免重复。无凭据保持DRAFT_LOCAL，不自动merge/删分支/worktree，创建PR也不表示获批。
