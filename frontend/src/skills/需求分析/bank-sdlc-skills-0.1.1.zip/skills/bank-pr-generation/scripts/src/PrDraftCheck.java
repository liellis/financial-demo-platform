import org.json.*;
public final class PrDraftCheck{
 public static void main(String[] a){Support.mainEntry(a,"S21",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));Support.requireFields(s,p,"title","body_path","target_branch","review_manifest_ref","candidate_snapshot");
  s.file(p.getString("body_path"));s.file(p.getString("review_manifest_ref"));
  s.check("PR_LOCAL_ONLY",p.optString("external_action").equals("DRAFT_LOCAL")&&p.isNull("pr_url"),"This helper only validates local drafts");
  s.check("PR_BRANCH",!p.getString("target_branch").startsWith("-")&&!p.getString("target_branch").contains(".."),"Explicit valid-looking branch");
  s.facts.put("external_write_performed",false);
 });}
}
