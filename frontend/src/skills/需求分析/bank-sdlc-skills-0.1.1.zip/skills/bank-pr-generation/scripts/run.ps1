param([Parameter(ValueFromRemainingArguments=$true)][string[]]$TaskArguments)
$ErrorActionPreference="Stop"
$TaskTemp=$null
try {
 $TaskJava="java"; $TaskJavac="javac"
 if($env:JAVA_HOME){$TaskJava=Join-Path $env:JAVA_HOME "bin/java.exe";$TaskJavac=Join-Path $env:JAVA_HOME "bin/javac.exe"}
 & $TaskJava -version 2>$null
 if($LASTEXITCODE -ne 0){throw "ENV_MISSING"}
 & $TaskJavac -version 2>$null
 if($LASTEXITCODE -ne 0){throw "ENV_MISSING"}
 $TaskTemp=Join-Path ([IO.Path]::GetTempPath()) ("bank-skill-"+[guid]::NewGuid())
 New-Item -ItemType Directory -Path $TaskTemp | Out-Null
 $TaskSources=@(Get-ChildItem (Join-Path $PSScriptRoot "src"),(Join-Path $PSScriptRoot "vendor") -Recurse -Filter *.java | ForEach-Object {$_.FullName})
 & $TaskJavac -encoding UTF-8 -source 8 -target 8 -d (Join-Path $TaskTemp "classes") @TaskSources 2>(Join-Path $TaskTemp "compile.log")
 if($LASTEXITCODE -ne 0){throw "COMPILE_ERROR"}
 & $TaskJava -Xmx256m -Dfile.encoding=UTF-8 -cp (Join-Path $TaskTemp "classes") PrDraftCheck @TaskArguments
 $TaskExit=$LASTEXITCODE
} catch {
 $TaskExit=4
 if($_.Exception.Message -eq "ENV_MISSING" -or $_.Exception -is [System.Management.Automation.CommandNotFoundException]){$TaskExit=3}
 Write-Output '{"status":"BLOCKED","error_code":"ENV_OR_EXECUTION_ERROR"}'
} finally {
 if($TaskTemp -and (Test-Path $TaskTemp)){Remove-Item -LiteralPath $TaskTemp -Recurse -Force}
}
exit $TaskExit
