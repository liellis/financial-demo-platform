---
name: bank-pr-generation
description: PR 生成；从审查包生成本地PR标题、描述和检查清单；默认不push、创建远端PR或合并。
metadata:
  skill-id: "S21"
  version: "0.1.1"
---

# PR 生成

从审查包生成本地PR标题、描述和检查清单；默认不push、创建远端PR或合并。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 S20、候选分支/提交、客户 PR 模板和目标分支；未知分支不自动猜。
2. 核对 diff 与审查包一致，生成具体问题、改变后的行为、实际验证和剩余限制。
3. 引用客户可访问的仓库相对路径或工单链接；本机绝对路径不能充当远端 reviewer 可访问证据。
4. 审阅输出，移除凭据、真实客户数据及不应离开发区的原始日志。
5. 默认保存草稿。只有用户明确授权外部创建/推送且客户权限允许时，才调用现有工具；失败不重复创建。
6. 记录外部 PR URL 与提交 SHA，返回客户流程；创建成功不等于获批合并。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类PrDraftCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`review/pr-title.txt`、`review/pr-body.md`、`pr-draft.json`；source_snapshot、target_branch、review_manifest_ref、external_action、authorization_ref、pr_url。未创建时 pr_url=null。

使用[业务模板](templates/pr-draft.json)与[输出结构](schemas/pr-draft.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需 Git 平台、分支/工单规范和 reviewer 职责。强制门禁不满足时可生成标明阻塞的草稿，不能描述为已可合并。

## 按需参考

- [git-provider-boundaries](references/git-provider-boundaries.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
