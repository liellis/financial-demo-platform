# S18 派生记录

- [templates/commands/analyze.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/analyze.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。
- [src/core/templates/workflows/verify-change.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/verify-change.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S18-D01：建立 AC→case→测试定义→执行实例→结果链，支持一对多/多对一。
- S18-D02：新增 TraceCheck：引用存在、版本一致、执行命中、跳过及失效检测。
- S18-D03：新增语义核对清单与人审字段，防止“关联了方法但没断言该规则”。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
