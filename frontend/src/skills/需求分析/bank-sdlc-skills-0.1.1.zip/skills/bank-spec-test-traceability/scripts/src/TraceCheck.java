import org.json.*;import java.util.*;
public final class TraceCheck{
 public static void main(String[] a){Support.mainEntry(a,"S18",s->{
  JSONObject spec=Support.payload(s.artifact("spec","delta_spec")),mapping=Support.payload(s.artifact("mapping","test_mapping"));
  s.check("TRACE_SPEC_CONFIRMED",Support.confirmed(spec.getJSONObject("confirmation")),"Spec is confirmed");
  Set<String> ac=s.ids(spec.getJSONArray("acceptance_criteria"),"ac_id","AC_ID");
  Map<String,List<JSONObject>> runs=new LinkedHashMap<String,List<JSONObject>>();boolean allGreen=true;
  String candidate=null;
  for(Object path:s.request.getJSONArray("runs")){JSONObject r=RunEvidence.load(s,path.toString(),true);allGreen&=RunEvidence.green(r);
   String digest=r.getJSONObject("after_snapshot").getString("digest");if(candidate==null)candidate=digest;
   s.check("TRACE_SAME_CANDIDATE",candidate.equals(digest),"All required runs validate one candidate");
   for(Object x:r.getJSONArray("cases")){JSONObject c=(JSONObject)x;String id=c.getString("id");if(!runs.containsKey(id))runs.put(id,new ArrayList<JSONObject>());runs.get(id).add(c);}}
  JSONArray rows=mapping.getJSONArray("rows"),result=new JSONArray();Set<String> mapped=s.ids(rows,"ac_id","TRACE_AC_UNIQUE");
  s.check("TRACE_AC_SET",mapped.equals(ac),"Every active AC has exactly one mapping row");
  s.check("TRACE_RUNS_GREEN",allGreen&&!runs.isEmpty(),"Required runs are green and non-flaky");
  Map<String,String> oracles=new HashMap<String,String>();
  for(Object x:spec.getJSONArray("acceptance_criteria")){JSONObject c=(JSONObject)x;oracles.put(c.getString("ac_id"),c.getString("oracle_ref"));
   s.check("TRACE_SPEC_ORACLE",c.optBoolean("oracle_confirmed"),"Spec oracle is confirmed");}
  int covered=0;
  for(Object x:rows){JSONObject row=(JSONObject)x;String id=row.getString("ac_id");boolean ok=true;
   JSONArray tests=row.getJSONArray("test_ids");s.check("TRACE_TESTS",tests.length()>0,"AC has test instances");
   for(Object t:tests){List<JSONObject> rs=runs.get(t.toString());boolean pass=rs!=null&&!rs.isEmpty();
    if(rs!=null)for(JSONObject r:rs)pass&=r.getString("status").equals("PASSED");
    s.check("TRACE_EXECUTION",pass,"Mapped instance ran and passed: "+t);ok&=pass;}
   boolean oracle=Objects.equals(oracles.get(id),row.optString("oracle_ref"))&&row.optBoolean("oracle_confirmed");
   s.check("TRACE_ORACLE_VERSION",oracle,"AC mapping uses confirmed current oracle");ok&=oracle;
   boolean semantic=Support.present(row,"semantic_review_ref");if(!semantic)s.confirm("TRACE_SEMANTIC","ID mapping does not prove assertions cover the AC");
   if(ok&&semantic&&allGreen&&tests.length()>0)covered++;
   result.put(new JSONObject().put("ac_id",id).put("tests",tests).put("execution_passed",ok).put("semantic_reviewed",semantic));
  }
  s.facts.put("rows",result).put("numerator",covered).put("denominator",ac.size()).put("candidate_digest",candidate)
   .put("spec_path",s.request.getString("spec")).put("spec_sha256",Support.sha(s.file(s.request.getString("spec"))))
   .put("mapping_path",s.request.getString("mapping")).put("mapping_sha256",Support.sha(s.file(s.request.getString("mapping"))))
   .put("run_paths",s.request.getJSONArray("runs"));
 });}
}
