---
name: bank-spec-test-traceability
description: 规格测试追溯；将AC关联到测试实例与实际运行，检查跳过、缺失、过期和Oracle版本，生成可复核追溯矩阵。
metadata:
  skill-id: "S18"
  version: "0.1.1"
---

# 规格测试追溯

将AC关联到测试实例与实际运行，检查跳过、缺失、过期和Oracle版本，生成可复核追溯矩阵。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取确认 Spec、S15计划、测试定义侧表、S16结果和当前快照。
2. 校验 AC/BR/case/test ID，撤销项保留历史，参数化测试明确对应参数集。
3. 对每个 AC 核对是否存在计划、实现、执行、有效结果及相同 Oracle 版本。
4. skipped/not discovered/环境阻塞/STALE 分别计状态，不能被其他无关测试通过抵消。
5. 模型或 QA 检查断言语义，关键业务 Oracle 须独立复核；仅结构关联通过仍可能 NEEDS_CONFIRMATION。
6. 输出逐 AC 矩阵、未覆盖及未自动化项；计算覆盖时注明分子、分母、排除理由及版本。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类TraceCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

`traceability.json/md`；rows[{ac_id,case_ids,test_ids,run_ids,result,semantic_review,oracle_ref,missing_evidence}]、counts、exclusions。不输出无分母的“覆盖100%”。

使用[业务模板](templates/traceability.json)与[输出结构](schemas/traceability.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需需求编号、用例系统映射和关键规则 reviewer。手工验收必须有批准来源和结果引用，不能把“计划人工执行”当已完成。

## 按需参考

- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。
