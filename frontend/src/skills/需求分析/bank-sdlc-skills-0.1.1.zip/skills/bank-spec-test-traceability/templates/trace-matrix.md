# 规格测试追溯

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`traceability.json/md`；rows[{ac_id,case_ids,test_ids,run_ids,result,semantic_review,oracle_ref,missing_evidence}]、counts、exclusions。不输出无分母的“覆盖100%”。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
