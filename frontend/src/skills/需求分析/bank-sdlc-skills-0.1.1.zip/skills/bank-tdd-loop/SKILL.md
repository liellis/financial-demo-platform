---
name: bank-tdd-loop
description: TDD 循环；按有效Red、最小实现、目标/保护/回归验证组织有限TDD循环，核对状态和预算；不是独立调度器。
metadata:
  skill-id: "S25"
  version: "0.1.1"
---

# TDD 循环

按有效Red、最小实现、目标/保护/回归验证组织有限TDD循环，核对状态和预算；不是独立调度器。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 task、风险、范围、Spec、保护基线及 Red；无有效 Red 或无允许动作时停止实现。
2. 核对 profile 的 max_cycles、总时限和变更预算，未配置先确认；不以无限重试代替诊断。
3. 进入 IMPLEMENT：按 S14 方法仅做最小实现，不改目标 Oracle。
4. 进入 VERIFY_TARGET：按 S16 执行目标；失败先读取证据，依 F06 按复现→单一假设→最小验证诊断。
5. 目标 Green 后进入 VERIFY_PROTECTION/REGRESSION；新增失败必须解释并修复，不能删用例或改跳过。
6. 所需测试通过后才可选择范围内 Refactor，再重复目标/保护/回归；无必要不重构。
7. 每轮保存候选快照、实际 run、假设、修改和预算消耗；达到限额、重复无证据假设、扩围或风险升高转人工。
8. 完成前运行 S17/S18 的方法并生成 S20；仅“目标 Green”状态不能输出整体完成。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类LoopCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

`tdd-session.json/md`；state、cycles[{hypothesis,changed_paths,snapshot,run_refs,result}]、budgets、blocked_reason、next_action、completion_refs。失败时保留工作区和 diff，不自动回滚用户代码。

使用[业务模板](templates/tdd-session.json)与[输出结构](schemas/tdd-session.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需循环/时间预算、人工接管条件、必需回归集和关键规则审查。预算增加或范围变化须明确确认，模型不能改配置续跑。

## 按需参考

- [tdd-transition-table](references/tdd-transition-table.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。

回归阶段材料见[regression_verification模板](templates/regression-verification.json)，字段只引用真实检查/运行结果。
