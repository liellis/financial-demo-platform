# tdd-transition-table

DRAFT→READY：确认输入；READY→BASELINED：实际保护基线；BASELINED→RED_VALIDATED：有效Red；→IMPLEMENTING：范围许可；→TARGET_GREEN：目标实际通过；→REGRESSION_VERIFIED：保护/回归；→REVIEW_READY：质量/追溯/审查。

失败先复现并按单一假设验证；每轮记修改、run及预算。重构后重验，Green不能跳回归。预算尽、扩围、Oracle/Spec变化、事务/权限升风险转人工，保留现场不reset/提交/合并。
