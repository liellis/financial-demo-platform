# S25 派生记录

- [skills/test-driven-development/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/systematic-debugging/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/systematic-debugging/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/executing-plans/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/executing-plans/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S25-D01：删除自动调子 Agent、worktree、提交与合并；按同一会话中的工件执行。
- S25-D02：新增循环预算、状态转换证据、工作区保留及“失败不弱化测试”的禁止项。
- S25-D03：新增 resume 检查，恢复前验证快照与输入，旧状态不能成为跳过 Red 的通行证。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
