import org.json.*;import java.util.*;
public final class LoopCheck{
 private static final Map<String,List<String>> NEXT=new HashMap<String,List<String>>();
 static{
  NEXT.put("DRAFT",Arrays.asList("READY"));NEXT.put("READY",Arrays.asList("BASELINED"));NEXT.put("BASELINED",Arrays.asList("RED_VALIDATED"));
  NEXT.put("RED_VALIDATED",Arrays.asList("IMPLEMENTING"));NEXT.put("IMPLEMENTING",Arrays.asList("IMPLEMENTING","TARGET_GREEN"));
  NEXT.put("TARGET_GREEN",Arrays.asList("IMPLEMENTING","REGRESSION_VERIFIED"));NEXT.put("REGRESSION_VERIFIED",Arrays.asList("IMPLEMENTING","REVIEW_READY"));
  NEXT.put("REVIEW_READY",Collections.<String>emptyList());
 }
 static void red(Support s,String path)throws Exception{
  JSONObject r=Evidence.result(s,path,"S24",true);Evidence.inputsCurrent(s,r);JSONObject f=r.getJSONObject("facts");
  s.check("LOOP_VALID_RED",f.getBoolean("red_valid"),"Actual valid Red precedes implementation");
  s.check("LOOP_SPEC_UNCHANGED",Support.sha(s.file(f.getString("spec_path"))).equals(f.getString("spec_sha256")),"Oracle/spec unchanged since Red");
  s.check("LOOP_PLAN_UNCHANGED",Support.sha(s.file(f.getString("plan_path"))).equals(f.getString("plan_sha256")),"Criticality/test plan unchanged since Red");
  JSONObject run=RunEvidence.load(s,f.getString("run_path"),false);
  s.check("LOOP_RED_BASELINE",run.getJSONObject("production_before").similar(f.getJSONObject("production_baseline"))&&run.getJSONObject("production_after").similar(f.getJSONObject("production_baseline")),"Red production baseline is unchanged");
 }
 static void regression(Support s,String path,JSONObject policy,String baseline,JSONObject current,boolean fresh)throws Exception{
  JSONObject a=Evidence.artifact(s,path,"regression_verification"),p=a.getJSONObject("payload");
  String digest=current.getJSONObject("after_snapshot").getString("digest");
  s.check("LOOP_REGRESSION_CANDIDATE",digest.equals(a.optString("source_snapshot")),"Regression bundle belongs to candidate");
  JSONObject protection=Evidence.result(s,p.getString("protection_check"),"S23",true);Evidence.inputsCurrent(s,protection);
  JSONObject pf=protection.getJSONObject("facts");
  s.check("LOOP_PROTECTION_BASE",baseline.equals(pf.getString("baseline_run")),"Protection compares the recorded pre-change baseline");
  s.check("LOOP_PROTECTION_CURRENT",digest.equals(pf.getString("candidate_digest")),"Protection validates this candidate");
  JSONArray requiredProtection=Support.stringArray(policy,"protection_test_ids"),mandatory=Support.stringArray(policy,"mandatory_test_ids");
  s.check("LOOP_REQUIRED_SETS",requiredProtection.length()>0&&mandatory.length()>0,"Customer protection and mandatory regression sets are explicit");
  Set<String> protectedIds=Support.strings(pf.getJSONArray("protected_test_ids"));
  s.check("LOOP_PROTECTION_SET",protectedIds.containsAll(Support.strings(requiredProtection)),"No required protection case omitted");
  JSONObject before=RunEvidence.load(s,baseline,false),after=RunEvidence.load(s,pf.getString("candidate_run"),fresh);
  Map<String,JSONObject> b=RunEvidence.cases(before),c=RunEvidence.cases(after);
  for(String id:protectedIds)s.check("LOOP_PROTECTION_PASSED",b.containsKey(id)&&c.containsKey(id)&&"PASSED".equals(b.get(id).getString("status"))&&"PASSED".equals(c.get(id).getString("status")),"Protected instance passed on both sides: "+id);
  JSONObject selected=Evidence.result(s,p.getString("regression_plan"),"S19",true);Evidence.inputsCurrent(s,selected);
  JSONObject sf=selected.getJSONObject("facts");s.check("LOOP_PLAN_CANDIDATE",digest.equals(sf.optString("candidate_digest")),"Regression selection belongs to candidate");
  Set<String> required=new HashSet<String>();for(Object x:sf.getJSONArray("selected"))required.add(((JSONObject)x).getString("test_id"));
  s.check("LOOP_MANDATORY_SELECTED",required.containsAll(Support.strings(mandatory)),"Plan includes customer mandatory set");required.addAll(Support.strings(mandatory));
  Set<String> passed=new HashSet<String>();JSONArray runs=Support.stringArray(p,"regression_runs");
  for(Object x:runs){JSONObject r=RunEvidence.load(s,x.toString(),fresh);
   s.check("LOOP_REGRESSION_GREEN",RunEvidence.green(r)&&digest.equals(r.getJSONObject("after_snapshot").getString("digest")),"Regression run green on this candidate");
   for(JSONObject t:RunEvidence.cases(r).values())if("PASSED".equals(t.getString("status")))passed.add(t.getString("id"));}
  s.check("LOOP_REGRESSION_EXECUTED",!required.isEmpty()&&passed.containsAll(required),"All selected and mandatory regression instances actually passed");
 }
 public static void main(String[] a){Support.mainEntry(a,"S25",s->{
  JSONObject p=Support.payload(s.artifact("artifact","tdd_session")),policy=s.json(Evidence.profilePath(s.request.getString("policy")));
  JSONObject limits=policy.getJSONObject("tdd_limits");int max=limits.getInt("max_cycles"),minutes=limits.getInt("timeout_minutes");
  s.check("LOOP_LIMITS",max>0&&minutes>0,"Finite positive customer budget");
  if(!Support.present(policy,"approval_ref"))s.confirm("LOOP_POLICY","Loop limits need approved customer policy");
  JSONArray cycles=p.getJSONArray("cycles");s.check("LOOP_BUDGET",cycles.length()<=max,"Cycle budget");
  long elapsed=java.time.Duration.between(java.time.OffsetDateTime.parse(p.getString("started_at")),java.time.OffsetDateTime.now()).getSeconds();
  s.check("LOOP_TIME",elapsed>=0&&elapsed<=minutes*60L,"Session time budget computed from start timestamp");
  String state="DRAFT",baseline=null,lastRed=null,lastTarget=null,lastRegression=null,lastReview=null;int implementations=0;
  for(Object x:p.getJSONArray("transitions")){JSONObject t=(JSONObject)x;String next=t.getString("to");
   s.check("LOOP_TRANSITION",t.getString("from").equals(state)&&NEXT.containsKey(state)&&NEXT.get(state).contains(next),"Valid state transition");
   if(next.equals("IMPLEMENTING"))implementations++;
   if(Arrays.asList("BASELINED","RED_VALIDATED","TARGET_GREEN","REGRESSION_VERIFIED","REVIEW_READY").contains(next)){
    String ref=t.getString("evidence_path");s.check("LOOP_EVIDENCE_HASH",Support.sha(s.file(ref)).equals(t.getString("evidence_sha256")),"Transition evidence unchanged");
    if(next.equals("BASELINED")){baseline=ref;JSONObject r=RunEvidence.load(s,ref,false);s.check("LOOP_BASELINE_GREEN",RunEvidence.green(r),"Pre-change baseline actually ran and passed");}
    if(next.equals("RED_VALIDATED")){lastRed=ref;red(s,ref);}
    if(next.equals("TARGET_GREEN")){lastTarget=ref;s.check("LOOP_TARGET_GREEN",RunEvidence.green(RunEvidence.load(s,ref,false)),"Target phase has an actual green run");lastRegression=null;}
    if(next.equals("REGRESSION_VERIFIED")){
     lastRegression=ref;if(lastTarget==null||baseline==null)throw new IllegalArgumentException("Missing prior baseline/target");
     // Check historical cycles against their own candidate; final freshness is checked below.
     regression(s,ref,policy,baseline,RunEvidence.load(s,lastTarget,false),false);
    }
    if(next.equals("REVIEW_READY")){lastReview=ref;Evidence.result(s,ref,"S20",true);}
   }
   state=next;
  }
  s.check("LOOP_STATE",state.equals(p.getString("state")),"Current state follows transitions");
  s.check("LOOP_CYCLE_ACCOUNTING",implementations==cycles.length(),"Every implementation transition consumes a recorded cycle");
  if(Arrays.asList("IMPLEMENTING","TARGET_GREEN","REGRESSION_VERIFIED","REVIEW_READY").contains(state)){
   s.check("LOOP_RED_LINK",Objects.equals(lastRed,p.getString("red_evidence")),"Session uses the validated Red transition");red(s,p.getString("red_evidence"));
   JSONObject risk=Evidence.risk(s,p.getString("risk_check"));
   s.check("LOOP_RISK_POLICY",risk.getString("policy_path").equals(s.request.getString("policy")),"Session and risk use the same customer policy");
   JSONObject b=RunEvidence.load(s,baseline,false),rf=s.json(p.getString("red_evidence")).getJSONObject("facts");
   s.check("LOOP_BASELINE_BEFORE_RED",b.getJSONObject("production_after").similar(rf.getJSONObject("production_baseline")),"Protection baseline precedes production implementation");
  }
  if(Arrays.asList("TARGET_GREEN","REGRESSION_VERIFIED","REVIEW_READY").contains(state)){
   s.check("LOOP_TARGET_LINK",Objects.equals(lastTarget,p.getString("current_run")),"Session uses the latest target transition");
   JSONObject current=RunEvidence.load(s,p.getString("current_run"),true);s.check("LOOP_CURRENT_GREEN",RunEvidence.green(current),"Current target run is green");
   if(Arrays.asList("REGRESSION_VERIFIED","REVIEW_READY").contains(state))regression(s,lastRegression,policy,baseline,current,true);
   if(state.equals("REVIEW_READY")){
    s.check("LOOP_REVIEW_LINK",Objects.equals(lastReview,p.getString("review_package")),"Review transition matches completion reference");
    JSONObject review=Evidence.result(s,p.getString("review_package"),"S20",true);Evidence.inputsCurrent(s,review);
    s.check("LOOP_REVIEW_SNAPSHOT",review.getJSONObject("facts").getString("candidate_digest").equals(current.getJSONObject("after_snapshot").getString("digest")),"Review belongs to candidate");
   }
  }
  s.facts.put("state",state).put("cycles_used",cycles.length()).put("next_allowed_states",new JSONArray(NEXT.containsKey(state)?NEXT.get(state):Collections.emptyList()))
   .put("workflow_executed",false).put("workspace_reset",false);
 });}
}
