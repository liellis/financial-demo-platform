# TDD 循环

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`tdd-session.json/md`；state、cycles[{hypothesis,changed_paths,snapshot,run_refs,result}]、budgets、blocked_reason、next_action、completion_refs。失败时保留工作区和 diff，不自动回滚用户代码。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
