import org.json.*;import java.util.*;
public final class RedCheck{
 public static void main(String[] a){Support.mainEntry(a,"S24",s->{
  JSONObject r=RunEvidence.load(s,s.request.getString("run"),true),oracle=s.request.getJSONObject("oracle"),baseline=s.json(s.request.getString("production_baseline"));
  if(baseline.has("facts"))baseline=baseline.getJSONObject("facts").getJSONObject("snapshot");
  JSONObject spec=Support.payload(s.artifact("spec","delta_spec"));String ac=s.request.getString("ac_id");boolean specOracle=false,specCritical=false;
  for(Object x:spec.getJSONArray("acceptance_criteria")){JSONObject criterion=(JSONObject)x;
   if(criterion.getString("ac_id").equals(ac)){
    specOracle=criterion.optBoolean("oracle_confirmed")&&criterion.getString("oracle_ref").equals(oracle.optString("reference"));specCritical=criterion.optBoolean("critical");}}
  JSONObject plan=Support.payload(s.artifact("test_plan","test_plan"));
  s.check("RED_PLAN_CONFIRMED",Support.confirmed(plan.getJSONObject("confirmation")),"Test plan criticality was confirmed");
  s.check("RED_PLAN_SPEC",plan.getString("spec_sha256").equals(Support.sha(s.file(s.request.getString("spec")))),"Plan belongs to the confirmed Spec revision");
  String caseId=s.request.getString("case_id");JSONObject target=null;
  for(Object x:plan.getJSONArray("cases"))if(((JSONObject)x).getString("case_id").equals(caseId)){
   if(target!=null)throw new IllegalArgumentException("Duplicate target case");target=(JSONObject)x;}
  if(target==null)throw new IllegalArgumentException("Target case missing");
  s.check("RED_PLAN_AC",Support.strings(target.getJSONArray("ac_ids")).contains(ac)&&target.getString("oracle_ref").equals(oracle.optString("reference")),"Case AC and oracle match");
  s.check("RED_PLAN_TEST_IDS",Support.strings(Support.stringArray(target,"test_ids")).equals(Support.strings(Support.stringArray(s.request,"target_test_ids"))),"Red instances match the confirmed case");
  if(!(target.opt("critical") instanceof Boolean)||!(oracle.opt("critical") instanceof Boolean))throw new IllegalArgumentException("Explicit criticality required");
  boolean critical=specCritical||target.getBoolean("critical");
  s.check("RED_CRITICALITY",oracle.getBoolean("critical")==critical,"Request cannot reclassify confirmed criticality");
  s.check("RED_SPEC_ORACLE",specOracle&&Support.confirmed(spec.getJSONObject("confirmation")),"Confirmed AC and oracle match the supplied target");
  boolean production=r.getJSONObject("production_before").similar(baseline)&&r.getJSONObject("production_after").similar(baseline);
  s.check("RED_PRODUCTION_UNCHANGED",production,"Production is unchanged from approved pre-test baseline");
  boolean oracleOk=oracle.optBoolean("confirmed")&&oracle.optBoolean("independent")&&Support.present(oracle,"reference");
  s.check("RED_ORACLE",oracleOk,"Oracle is confirmed and independent");
  boolean semantic=Support.present(s.request,"semantic_review_ref");
  if(critical)semantic &= Support.present(s.request,"independent_qa_review_ref")&&Support.present(target,"review_ref");
  s.check("RED_SEMANTIC_REVIEW",semantic,"Assertion failure was reviewed against the target AC");
  Map<String,JSONObject> cases=RunEvidence.cases(r);JSONArray ids=s.request.getJSONArray("target_test_ids");boolean failed=ids.length()>0;
  Set<String> targets=Support.strings(ids);
  for(Object id:ids){JSONObject c=cases.get(id.toString());boolean ok=c!=null&&c.getString("status").equals("FAILED")&&c.getString("failure_kind").equals("ASSERTION");
   s.check("RED_TARGET_ASSERTION",ok,"Target actually executed with assertion failure: "+id);failed &= ok;}
  boolean clean=true;
  for(Map.Entry<String,JSONObject> e:cases.entrySet())if(!targets.contains(e.getKey())&&!e.getValue().getString("status").equals("PASSED"))clean=false;
  s.check("RED_NO_UNRELATED_FAILURE",clean,"No unrelated failure/error/skip in target run");
  boolean build=r.getInt("exit_code")!=0&&r.getInt("exit_code")!=-1&&r.getInt("errors")==0&&r.getInt("skipped")==0&&!r.optBoolean("flaky")
   &&r.getInt("executed_count")>0&&r.getInt("failed")>0&&r.getString("failure_phase").equals("TEST_ASSERTION_OR_FAILURE");
  s.check("RED_TEST_FAILURE_PHASE",build,"Actual nonzero test failure, not compile/env/timeout/flaky");
  boolean valid=s.passed()&&production&&oracleOk&&semantic&&failed&&clean&&build;
  s.facts.put("red_valid",valid).put("target_test_ids",ids).put("run_id",r.getString("run_id")).put("oracle_ref",oracle.optString("reference"))
   .put("spec_path",s.request.getString("spec")).put("spec_sha256",Support.sha(s.file(s.request.getString("spec")))).put("ac_id",ac)
   .put("plan_path",s.request.getString("test_plan")).put("plan_sha256",Support.sha(s.file(s.request.getString("test_plan"))))
   .put("case_id",caseId).put("critical",critical).put("run_path",s.request.getString("run")).put("production_baseline",baseline)
   .put("flow_deviation",s.request.optString("flow_deviation","NONE"));
 });}
}
