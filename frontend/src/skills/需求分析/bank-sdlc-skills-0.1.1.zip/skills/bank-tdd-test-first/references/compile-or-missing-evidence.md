# 缺失运行证据时

只有编译日志不能确认Red。列出：run-record、精确目标选择器/实例、原始XML及摘要、源码/生产前后快照、批准profile摘要、确认Spec/AC/Oracle、失败语义复核引用。缺任一关键项标BLOCKED或FAIL，不补写运行事实。
