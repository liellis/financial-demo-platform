# S24 派生记录

- [skills/test-driven-development/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/test-driven-development/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/verification-before-completion/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/verification-before-completion/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S24-D01：将通用测试示例改为客户 JUnit/Mockito 风格；删除自动删掉先写实现的指令。
- S24-D02：新增 Red 证据合同：目标测试被发现并实际执行、断言失败与目标 AC相关、生产代码未变、基线未新增无关失败。
- S24-D03：新增关键测试独立复核、预期确认及测试完整性检查；不能为了 Red 暂时破坏生产代码。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
