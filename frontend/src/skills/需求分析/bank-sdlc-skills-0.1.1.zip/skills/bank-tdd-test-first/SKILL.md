---
name: bank-tdd-test-first
description: 测试先行；为确认变更编写目标测试，核验生产未变、独立Oracle和真实断言失败；编译或环境错误不能算Red。
metadata:
  skill-id: "S24"
  version: "0.1.1"
---

# 测试先行

为确认变更编写目标测试，核验生产未变、独立Oracle和真实断言失败；编译或环境错误不能算Red。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取确认 Spec、S15、允许范围、风险动作、S23基线及 Oracle；关键预期缺来源则停止。
2. 保存生产与测试前快照；若发现已先写的实现，保留现场并标 NON_STANDARD，选择补证/人工路径，不声称严格测试先行。
3. 只修改已允许的目标测试/测试资源，使用真实被测逻辑；代码编译所必需的接口桩也须显式记录，不能藏入生产实现。
4. 通过宿主使用 S16 方法运行精确目标选择器，采集实际报告与快照。
5. RedCheck 核对：目标实例执行、存在预期断言差异、生产摘要未变、报告新鲜；编译/加载/连接/超时或0测试立即判无效。
6. 模型/QA复核失败消息是否对应目标 AC，不能只看 failed>0；关键业务 Oracle 按客户规则独立确认。
7. 无有效 Red 时先诊断测试/环境或需求；若原实现已满足需求，报告“无需该行为修改”，不制造失败。
8. 产出有效 Red 或阻塞报告，交 S25/S14；只写测试不代表业务需求完成。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类RedCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

目标测试、`red-evidence.json/md`；ac_id、case_id、target_test_ids、oracle_ref、production_baseline_hash、run_ref、failure_category、assertion_evidence、semantic_review、red_valid、deviation。red_valid 只有明确条件齐备才 true。

使用[业务模板](templates/red-evidence.json)与[输出结构](schemas/red-evidence.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需预期来源、关键测试复核岗位、数据及环境。L3 未获允许时仅出测试设计，不能借“测试先行”执行未经授权的数据或交易操作。

## 按需参考

- [effective-red](references/effective-red.md)：对应步骤判断。
- [junit-bank-examples](references/junit-bank-examples.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

只有日志/编译错误而没有运行工件时，先读[缺失证据清单](references/compile-or-missing-evidence.md)，输出具体缺口，不用通用JSON错误替代解释。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。
