# 测试先行

状态：NEEDS_CONFIRMATION

来源ID与摘要：

目标测试、`red-evidence.json/md`；ac_id、case_id、test_instance_ids、oracle_ref、production_baseline_hash、run_ref、failure_category、assertion_evidence、semantic_review、red_valid、deviation。red_valid 只有明确条件齐备才 true。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
