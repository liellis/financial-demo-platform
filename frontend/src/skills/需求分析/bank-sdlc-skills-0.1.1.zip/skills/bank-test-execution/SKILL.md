---
name: bank-test-execution
description: 测试执行与分析；执行客户批准的离线Maven/Gradle测试命令，采集本轮XML、实际用例、退出码与快照；不把零测试当通过。
metadata:
  skill-id: "S16"
  version: "0.1.1"
---

# 测试执行与分析

执行客户批准的离线Maven/Gradle测试命令，采集本轮XML、实际用例、退出码与快照；不把零测试当通过。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 输入批准 command_id、选择器、预计模块和测试 ID；读取具体 argv、cwd、超时、报告目录与资源约束。
2. 保存运行前快照和原报告摘要；优先将报告定向到本次独立目录。工具不能独立定向时先备份并隔离已知报告，禁止删除工程或客户数据。
3. 通过本项 TestRun 的 ProcessBuilder 启动批准的构建命令，不拼接 shell；记录原始退出码及脱敏输出。依赖默认只访问客户批准源，不自动切公网。
4. 等待进程退出；超时终止自己启动的进程树，未确认终止则明确残留风险，不能继续同目录运行。
5. 从批准目录读取本次新产生报告，核对模块、选择器、时间及文件摘要；只看时间戳不够，旧文件无法排除时 UNKNOWN。
6. 安全解析 JUnit XML，逐用例记录 passed/failed/error/skipped；测试未发现、动态参数无法关联分别标明，不能归入 passed。
7. 比对运行前后快照；输出实际选择命中、数量和错误阶段，发现“退出码0但0测试”或报告缺失则阻断验证通过。
8. 如经允许诊断重跑，原失败永久保留、关联 rerun_of，不能只展示最后一次 Green。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类TestRun。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

`runs/<run-id>/run.json`、raw-reports/、脱敏 console.log；command_digest、selector、started/ended_at、exit_code、failure_phase、before/after_snapshot、report_hashes、cases[]、discovered_count、executed_count、flaky、limits。发现数量无法确认时为 null，不编造总数。

使用[业务模板](templates/test-run.json)与[输出结构](schemas/test-run.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需构建插件版本、内网依赖、测试数据库、命令白名单、时限及并发限制。必需集成环境缺失时可跑单元测试，但总体验证保持 BLOCKED。

## 按需参考

- [maven-gradle-execution](references/maven-gradle-execution.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

本项程序的facts.run及run-record.json是规范运行事实。test-run业务模板仅供理解字段，不得由模型重填或修改运行计数；下游直接引用程序输出文件。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。
