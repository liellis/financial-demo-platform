# maven-gradle-execution

读取受控profile并核对摘要/owner/批准引用及本次执行授权，限定offline参数数组和单一selector。执行客户已有wrapper/工具，不装插件、不重写构建。

原XML逐文件移入本轮preexisting-reports，运行后只采新XML；0测试、缺报告、编译、环境、超时均阻断。逐case保留模块/class/参数名、失败/错误/跳过，discovered_count无法确认用null。

执行前后快照包括相关未跟踪源码、测试和构建；变化则STALE。超时终止所观察的子进程，保留锁，需人工核实清理再续跑。保留原失败及rerun/flaky；默认不记录可能泄密的console原文。
