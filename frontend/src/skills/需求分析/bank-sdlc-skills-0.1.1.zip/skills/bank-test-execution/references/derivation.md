# S16 派生记录

- [skills/verification-before-completion/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/verification-before-completion/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S16-D01：保留实际验证要求，新增 Maven Surefire/Failsafe、Gradle Test 的版本化 profile 和 XML 夹具。
- S16-D02：新增参数数组、时限、退出码、快照、报告新鲜度及参数化用例 ID；拒绝执行输入文件中任意命令。
- S16-D03：新增编译/环境/测试失败分类与 flaky 保留；不把失败原因自动认定为业务 Red。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
