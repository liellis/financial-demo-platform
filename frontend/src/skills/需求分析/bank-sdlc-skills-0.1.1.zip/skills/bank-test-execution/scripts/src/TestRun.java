import org.json.*;import java.nio.file.*;import java.nio.charset.*;import java.io.*;import java.time.*;import java.util.*;import java.util.concurrent.*;import java.security.*;
/** One approved build invocation. Never runs a workflow or a model. */
public final class TestRun{
 static void terminate(Process process){
  try{
   Object handle=Process.class.getMethod("toHandle").invoke(process);
   Class<?> ph=Class.forName("java.lang.ProcessHandle");
   java.util.stream.Stream<?> ds=(java.util.stream.Stream<?>)ph.getMethod("descendants").invoke(handle);
   try{ds.forEach(h->{try{ph.getMethod("destroyForcibly").invoke(h);}catch(Exception ignored){}});}finally{ds.close();}
  }catch(Exception ignored){/* JDK8: keep the execution lock on timeout; cleanup must be verified by operator. */}
  process.destroyForcibly();
 }
 public static void main(String[] a){Support.mainEntry(a,"S16",s->{
  JSONObject req=s.request;String profilePath=req.getString("profile");
  Evidence.profilePath(profilePath);
  JSONObject cfg=s.json(profilePath),cmd=null;
  for(Object x:cfg.getJSONArray("commands"))if(((JSONObject)x).getString("id").equals(req.getString("command_id"))){if(cmd!=null)throw new IOException("Duplicate command id");cmd=(JSONObject)x;}
  if(cmd==null)throw new IOException("Unknown command");
  boolean approved=Support.present(cfg,"approval_ref")&&Support.present(cfg,"owner")&&Support.present(req,"execution_authorization_ref");
  if(!approved){s.block("EXECUTION_NOT_AUTHORIZED","Approved profile and explicit execution authorization are required");return;}
  if(!Support.sha(s.file(profilePath)).equals(req.getString("expected_profile_sha256")))throw new IOException("Profile digest changed");
  String tool=cmd.getString("tool");if(!Arrays.asList("maven","gradle").contains(tool))throw new IOException("Unsupported build tool");
  String selector=req.getString("test_selector");
  if(selector.isEmpty()||selector.startsWith("-")||!selector.matches("[A-Za-z0-9_.$#,*\\[\\]-]{1,512}"))throw new IOException("Invalid selector");
  JSONArray template=cmd.getJSONArray("argv_template");List<String> argv=new ArrayList<String>();boolean used=false;
  for(Object x:template){String v=x.toString();if(v.contains("{test_selector}")){v=v.replace("{test_selector}",selector);used=true;}if(v.contains("{")||v.indexOf('\0')>=0)throw new IOException("Unknown placeholder");argv.add(v);}
  String executable=Paths.get(argv.get(0)).getFileName().toString().toLowerCase(Locale.ROOT);
  if(!(tool.equals("maven")?Arrays.asList("mvn","mvnw","mvn.cmd","mvnw.cmd"):Arrays.asList("gradle","gradlew","gradle.bat","gradlew.bat")).contains(executable))throw new IOException("Unexpected build executable");
  if(!used)throw new IOException("Command must apply explicit test selector");
  if(!"offline".equals(cmd.getString("network_policy"))||!(argv.contains("-o")||argv.contains("--offline")))throw new IOException("Initial runner supports explicit offline profiles only");
  int timeout=cmd.getInt("timeout_seconds");if(timeout<1||timeout>7200)throw new IOException("Invalid timeout");
  Path cwd=Support.inside(s.root,cmd.getString("cwd"),false);if(!Files.isDirectory(cwd))throw new IOException("Missing build working directory");
  String run=req.getString("run_id"),change=req.getString("change_id");
  if(!run.matches("[A-Za-z0-9][A-Za-z0-9-]{0,63}")||!change.matches("[A-Za-z0-9][A-Za-z0-9-]{0,63}"))throw new IOException("Invalid change/run ID");
  Path runDir=Support.inside(s.root,".sdlc/changes/"+change+"/runs/"+run,false);
  if(Files.exists(runDir))throw new IOException("Run exists; never reuse a run ID");
  JSONArray reports=cmd.getJSONArray("report_roots");
  if(reports.length()==0)throw new IOException("Report roots required");
  List<Path> reportDirs=new ArrayList<Path>();
  for(Object x:reports){String rp=x.toString();Path raw=Paths.get(rp),normalized=Support.inside(s.root,rp,false);
   if(raw.isAbsolute()||!rp.equals(rp.replace('\\','/'))||!raw.normalize().toString().replace('\\','/').equals(rp))throw new IOException("Canonical report root required");
   boolean output=false;int index=0;
   for(Path part:raw){if((part.toString().equals("target")||part.toString().equals("build"))&&index<raw.getNameCount()-1)output=true;index++;}
   if(!output)throw new IOException("Report root must be below a build output directory");
   for(Path other:reportDirs)if(normalized.startsWith(other)||other.startsWith(normalized))throw new IOException("Overlapping report roots");
   reportDirs.add(normalized);
  }
  ProjectFiles.approvedRoots(s,cmd,Support.stringArray(req,"snapshot_roots"),Support.stringArray(req,"production_roots"));
  ProjectFiles.diffCovered(s,req.getJSONArray("snapshot_roots"),req.getString("base_commit"));
  if(!s.passed())return;
  JSONArray sourcePaths=ProjectFiles.expand(s,req.getJSONArray("snapshot_roots")),productionPaths=ProjectFiles.expand(s,req.getJSONArray("production_roots"));
  Set<String> full=Support.strings(sourcePaths);if(!full.containsAll(Support.strings(productionPaths)))throw new IOException("Production snapshot not included in source roots");
  JSONObject before=s.snapshot(sourcePaths),prodBefore=s.snapshot(productionPaths);
  for(Path report:reportDirs)for(Object path:sourcePaths)if(s.file(path.toString()).startsWith(report))throw new IOException("Report directory overlaps source snapshot");
  // Preflight the complete old-report set before acquiring a lock or moving any file.
  List<Path> oldReports=JUnitXmlReader.reports(s,reports);
  for(Path old:oldReports)JUnitXmlReader.parse(old,"");
  Path lock=Support.inside(s.root,".sdlc/locks/test-execution.lock",false);Files.createDirectories(lock.getParent());
  try{Files.write(lock,(change+"/"+run).getBytes(StandardCharsets.UTF_8),StandardOpenOption.CREATE_NEW);}catch(FileAlreadyExistsException e){s.block("PROJECT_TEST_LOCK","A run or unverified timed-out process still owns the project lock");return;}
  boolean retainLock=false;Process process=null;
  try{
   Files.createDirectories(runDir.resolve("preexisting-reports"));Files.createDirectories(runDir.resolve("raw-reports"));
   int index=0;
   for(Path p:oldReports){
    Path dest=runDir.resolve("preexisting-reports").resolve((index++)+".xml");Files.move(p,dest);
   }
   String started=OffsetDateTime.now().toString();
   ProcessBuilder pb=new ProcessBuilder(argv).directory(cwd.toFile()).redirectErrorStream(true);
   // Credentials are inherited by the customer's approved build environment, never serialized here.
   process=pb.start();final Process child=process;final MessageDigest digest=MessageDigest.getInstance("SHA-256");
   final long[] outputBytes={0};final IOException[] drainError={null};
   Thread drainer=new Thread(()->{try(InputStream in=child.getInputStream()){byte[] b=new byte[8192];int n;
    while((n=in.read(b))!=-1){digest.update(b,0,n);outputBytes[0]+=n;if(outputBytes[0]>64L*1024*1024)throw new IOException("Build output budget exceeded");}}
    catch(IOException e){drainError[0]=e;terminate(child);}});
   drainer.setDaemon(true);drainer.start();
   boolean ended=process.waitFor(timeout,TimeUnit.SECONDS);
   if(!ended){retainLock=true;terminate(process);process.waitFor(3,TimeUnit.SECONDS);}
   drainer.join(3000);
   if(drainer.isAlive()||drainError[0]!=null){retainLock=true;terminate(process);}
   JSONObject after=s.snapshot(ProjectFiles.expand(s,req.getJSONArray("snapshot_roots"))),prodAfter=s.snapshot(ProjectFiles.expand(s,req.getJSONArray("production_roots")));
   JSONArray raw=new JSONArray(),cases=new JSONArray();Set<String> ids=new HashSet<String>();index=0;
   for(Path p:JUnitXmlReader.reports(s,reports)){
    String rel=s.root.relativize(p).toString().replace('\\','/'),module="";
    for(Object rp:reports)if(rel.startsWith(rp.toString().replace('\\','/')+"/"))module=rp.toString().replace('\\','/');
    Path dest=runDir.resolve("raw-reports").resolve((index++)+".xml");
    Files.copy(p,dest);String saved=s.root.relativize(dest).toString().replace('\\','/');
    raw.put(new JSONObject().put("path",saved).put("sha256",Support.sha(dest)).put("module",module));
    for(Object x:JUnitXmlReader.parse(dest,module)){JSONObject c=(JSONObject)x;if(!ids.add(c.getString("id")))throw new IOException("Duplicate report case identity");cases.put(c);}
   }
   int pass=0,fail=0,error=0,skip=0;
   for(Object x:cases){String st=((JSONObject)x).getString("status");if(st.equals("PASSED"))pass++;if(st.equals("FAILED"))fail++;if(st.equals("ERROR"))error++;if(st.equals("SKIPPED"))skip++;}
   boolean stable=before.getString("digest").equals(after.getString("digest"));
   int exit=ended&&!process.isAlive()?process.exitValue():-1;
   JSONArray expected=req.getJSONArray("expected_test_ids");s.check("EXPECTED_TESTS",expected.length()>0,"Expected instances must be declared");
   for(Object id:expected)s.check("TEST_DISCOVERED",ids.contains(id.toString()),"Expected instance executed: "+id);
   s.check("REPORTS_FRESH",raw.length()>0,"Only reports created after old XML isolation are accepted");
   s.check("TESTS_EXECUTED",cases.length()>0,"At least one actual test case");
   s.check("SOURCE_STABLE",stable,"Source/test/build snapshot unchanged during run");
   s.check("PROCESS_COMPLETED",ended&&!retainLock,"Build completed without unverified cleanup");
   s.check("BUILD_EXIT",exit==0,"Raw build exit code is zero");
   s.check("TEST_SUCCESS",fail==0&&error==0&&skip==0,"No failed/error/skipped test cases");
   String phase=!ended?"TIMEOUT":cases.length()==0?"BUILD_OR_ENVIRONMENT":error>0?"TEST_ERROR":fail>0?"TEST_ASSERTION_OR_FAILURE":"NONE";
   JSONObject record=new JSONObject().put("run_id",run).put("change_id",change).put("command_id",req.getString("command_id")).put("base_commit",req.getString("base_commit"))
    .put("profile_path",profilePath).put("profile_sha256",Support.sha(s.file(profilePath))).put("selector",selector)
    .put("started_at",started).put("ended_at",OffsetDateTime.now().toString()).put("exit_code",exit).put("failure_phase",phase)
    .put("before_snapshot",before).put("after_snapshot",after).put("production_before",prodBefore).put("production_after",prodAfter)
    .put("raw_reports",raw).put("cases",cases).put("passed",pass).put("failed",fail).put("errors",error).put("skipped",skip)
    .put("executed_count",cases.length()-skip).put("reported_count",cases.length()).put("discovered_count",JSONObject.NULL)
    .put("discovery_note","XML proves reported instances, not total engine discovery").put("flaky",req.has("rerun_of"))
    .put("rerun_of",req.opt("rerun_of")==null?JSONObject.NULL:req.get("rerun_of")).put("cleanup_unverified",retainLock)
    .put("snapshot_scope","DECLARED_SOURCE_AND_BUILD_ROOTS").put("snapshot_roots",req.getJSONArray("snapshot_roots"))
    .put("production_roots",req.getJSONArray("production_roots")).put("expected_test_ids",expected)
    .put("console_content_retained",false).put("console_bytes",outputBytes[0]);
   s.facts.put("run",record);
   Support.atomicNew(runDir.resolve("run-record.json"),record.toString(2)+"\n");
  }catch(Exception e){if(process!=null&&process.isAlive()){retainLock=true;terminate(process);}throw e;}
  finally{if(!retainLock)Files.deleteIfExists(lock);}
 });}
}
