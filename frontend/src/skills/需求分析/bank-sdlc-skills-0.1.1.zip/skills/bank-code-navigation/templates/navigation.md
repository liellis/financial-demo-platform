# 代码定位

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`navigation.json/md`；query_terms[]、candidates[{path,symbol,kind,reason,evidence}]、excluded[]、unresolved[]。S03/S04 不得把候选转换为确认事实而不增加证据。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
