import org.json.*;
public final class LocatorCheck{
 public static void main(String[] a){Support.mainEntry(a,"S02",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));JSONArray cs=p.getJSONArray("candidates");
  s.check("CANDIDATES",cs.length()>0,"At least one candidate or an explicit unresolved result is needed");
  java.util.Set<String> seen=new java.util.HashSet<String>();
  for(Object x:cs){JSONObject c=(JSONObject)x;Support.requireFields(s,c,"path","symbol","reason");
   s.file(c.getString("path"));s.check("CANDIDATE_UNIQUE",seen.add(c.getString("path")+"#"+c.getString("symbol")),"Candidate is unique");}
  s.evidenceRows(cs,"evidence");
  if(Support.arr(p,"unresolved").length()>0)s.unknown("UNRESOLVED","Navigation has unresolved candidates");
  s.facts.put("candidates_checked",cs.length());
 });}
}
