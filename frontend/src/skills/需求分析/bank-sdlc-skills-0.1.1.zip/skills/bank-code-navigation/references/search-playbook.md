# search-playbook

先将query拆为交易码、路径、错误码、术语及表字段。用固定字符串在批准模块搜索，再核对定义和配置，最后追实现与SQL。排除测试和注释命中时保存理由。

候选列path/symbol/kind/reason/evidence。接口多实现需查qualifier/profile/注册表；外部消费者缺源码时保持unknown，不输出‘无调用者’。
