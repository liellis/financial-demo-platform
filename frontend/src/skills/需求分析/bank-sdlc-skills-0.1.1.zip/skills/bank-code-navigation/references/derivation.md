# S02 派生记录

- [skills/systematic-debugging/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/systematic-debugging/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S02-D01：将 F06 的“复现→假设”简化为只读定位链，不在定位阶段试改代码。
- S02-D02：新增路由、服务接口、实现、SQL ID、错误码、批量任务名和术语别名的搜索模板。
- S02-D03：新增候选排序的可解释理由；不输出未经校准的“95%置信度”。源码定义、配置绑定优先于注释和相似名称。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
