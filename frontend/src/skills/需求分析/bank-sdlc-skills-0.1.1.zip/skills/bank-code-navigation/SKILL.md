---
name: bank-code-navigation
description: 代码定位；根据业务术语、路由、交易码或错误码定位代码候选，核对配置绑定和来源；用于进入规则或链路分析前。
metadata:
  skill-id: "S02"
  version: "0.1.1"
---

# 代码定位

根据业务术语、路由、交易码或错误码定位代码候选，核对配置绑定和来源；用于进入规则或链路分析前。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 query、S01 画像、允许目录、业务术语表和已有堆栈；query 中的账号等标识先脱敏。
2. 将问题拆成 API/错误码/领域词/表或字段/任务名，分别用固定字符串搜索，随后才做受限模式搜索。
3. 对候选读取限定上下文，核对符号定义、实际路由映射、接口实现和配置引用。
4. 对 Mapper 由 Java 方法追到 XML statement；对继承或代理关系查实际实现，未解析则列候选。
5. 输出首选、备选、排除理由与待业务确认项；只有多个相互支持证据才标“已定位入口”。
6. 将入口交 S03/S04；不能定位时报告已查范围和建议补充的脱敏样例，不扩大到禁读区。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类LocatorCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`navigation.json/md`；query_terms[]、candidates[{path,symbol,kind,reason,evidence}]、excluded[]、unresolved[]。S03/S04 不得把候选转换为确认事实而不增加证据。

使用[业务模板](templates/navigation.json)与[输出结构](schemas/navigation.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需业务简称、交易码、老系统包名和错误码目录。动态注册、源码缺失或多租户路由不明时 UNKNOWN，不能保证覆盖所有实现。

## 按需参考

- [search-playbook](references/search-playbook.md)：对应步骤判断。
- [bank-symbol-aliases.example](references/bank-symbol-aliases.example.json)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
