import org.json.*;import java.nio.charset.*;import java.util.regex.*;
public final class ContextPack{
 private static final Pattern SECRET=Pattern.compile("(?im)(-----BEGIN [A-Z ]*PRIVATE KEY-----|(?:password|passwd|secret|api[_-]?key|access[_-]?token)\\s*[:=]\\s*[^\\s]{3,}|\\b\\d{16,19}\\b)");
 public static void main(String[] a){Support.mainEntry(a,"S12",s->{
  JSONArray items=s.request.getJSONArray("items"),allow=s.request.getJSONArray("allow_paths"),deny=s.request.getJSONArray("deny_paths");
  int max=s.request.getInt("max_chars"),used=0;JSONArray kept=new JSONArray(),excluded=new JSONArray();
  for(Object x:items){JSONObject item=(JSONObject)x;String p=item.getString("path");
   if(!Support.anyGlob(p,allow)||Support.anyGlob(p,deny)||p.matches("(?i).*(\\.env|\\.pem|\\.key|credentials|application-prod[^/]*)$")){
    excluded.put(new JSONObject().put("path",p).put("reason","PATH_POLICY"));continue;}
   String text=new String(Support.bounded(s.file(p),1024*1024),StandardCharsets.UTF_8);String[] lines=text.split("\n",-1);
   int start=item.getInt("line_start"),end=item.getInt("line_end");
   if(start<1||end<start||end>lines.length)throw new java.io.IOException("Invalid context range");
   StringBuilder b=new StringBuilder();for(int i=start-1;i<end;i++)b.append(lines[i]).append('\n');String snippet=b.toString();
   if(SECRET.matcher(snippet).find()){excluded.put(new JSONObject().put("path",p).put("reason","POSSIBLE_SENSITIVE_VALUE"));s.confirm("CONTEXT_SENSITIVE","Review excluded source locally; matching value is not logged");continue;}
   if(used+snippet.length()>max){excluded.put(new JSONObject().put("path",p).put("reason","BUDGET"));s.unknown("CONTEXT_BUDGET","Required material may be missing");continue;}
   used+=snippet.length();kept.put(new JSONObject().put("path",p).put("line_start",start).put("line_end",end)
    .put("sha256",Support.sha(s.file(p))).put("trust_level","UNTRUSTED_SOURCE_DATA").put("content",snippet));
  }
  s.facts.put("items",kept).put("excluded",excluded).put("chars",used).put("budget_unit","UTF16_CHARS")
   .put("instructions_from_source","MUST_NOT_EXECUTE").put("secret_detection_complete",false);
 });}
}
