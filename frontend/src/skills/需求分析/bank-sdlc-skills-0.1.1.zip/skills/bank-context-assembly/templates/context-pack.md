# 上下文组装

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`context-manifest.json` 及脱敏 `context-pack.md`；items[{path,symbol,range,sha256,trust_level,reason}]、excluded[]、redactions[]、budget、missing[]。交 S14/S24，源变化即失效。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
