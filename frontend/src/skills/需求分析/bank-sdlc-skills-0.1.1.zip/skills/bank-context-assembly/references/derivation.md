# S12 派生记录

- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S12-D01：新增输入来源分层：治理规则、确认业务、源码事实、未确认材料；后两者不能发出改变系统权限的指令。
- S12-D02：新增按 task/AC/符号选择文件、片段摘要、内容预算与排除原因。
- S12-D03：新增敏感信息规则和间接提示注入案例；不把 .gitignore 视为防读取边界。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
