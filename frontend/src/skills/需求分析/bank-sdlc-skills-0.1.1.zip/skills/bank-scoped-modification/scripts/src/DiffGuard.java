import org.json.*;import java.util.*;import java.nio.charset.*;
public final class DiffGuard{
 public static void main(String[] a){Support.mainEntry(a,"S14",s->{
  JSONObject scope=Support.payload(s.artifact("scope","change_scope"));
  JSONObject rf=Evidence.risk(s,s.request.getString("risk"));
  s.check("RISK_SCOPE_BASE",scope.getString("base_commit").equals(rf.getString("base_commit")),"Risk and scope share baseline");
  s.check("SCOPE_CONFIRMED",Support.confirmed(scope),"Confirmed scope");GitDiff.scope(s,scope);
  String diff=new String(GitDiff.git(s,"diff","--no-ext-diff","--no-textconv","--unified=0",scope.getString("base_commit"),"--"),StandardCharsets.UTF_8);
  boolean concern=false;
  for(String l:diff.split("\n")){
   if(l.startsWith("-")&&!l.startsWith("---")&&(l.contains("assert")||l.contains("@Test")))concern=true;
   if(l.startsWith("+")&&(l.contains("@Disabled")||l.contains("@Ignore")||l.matches(".*(?:skipTests|maven.test.skip)\\s*[=:]\\s*true.*")))concern=true;
  }
  if(concern&&!Support.present(s.request,"test_change_review_ref"))s.confirm("TEST_INTEGRITY","Removed assertion/test or disabled check requires independent diff review");
  s.facts.put("test_integrity_candidate",concern).put("production_correctness","NOT_PROVEN");
 });}
}
