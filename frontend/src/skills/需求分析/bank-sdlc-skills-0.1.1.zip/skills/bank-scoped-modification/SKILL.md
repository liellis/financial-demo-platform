---
name: bank-scoped-modification
description: 范围受控修改；在风险许可和确认范围内做最小代码修改，保留用户差异并核查测试完整性与扩围。
metadata:
  skill-id: "S14"
  version: "0.1.1"
---

# 范围受控修改

在风险许可和确认范围内做最小代码修改，保留用户差异并核查测试完整性与扩围。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取 task、S06/S07/S12/S13、S23/S24；任一关键来源 STALE 或 L3 禁止则停止写生产代码。
2. 保存修改前 diff 和文件摘要，识别客户未提交部分；冲突文件先确认处理，不能覆盖。
3. 按单个行为做最小修改，不顺便重构、加依赖、改构建或扩大事务。
4. 对新增错误路径、资源关闭、日志敏感值、SQL 参数化及幂等分支进行局部自审。
5. 随附 DiffGuard 计算新 diff 与确认范围，核查路径、预算及测试删除/断言改动候选。
6. 调 S16 的方法运行批准测试；失败则交 S25 诊断并由 S06 重新评估风险，不自行改 Oracle。
7. 输出实际变更说明及偏离；若需新文件/公共组件变化，先修订 S07 并确认后继续。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类DiffGuard。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

业务/测试补丁及 `modification.json/md`；task_id、before/after snapshots、changed_paths、reason_by_hunk、scope_check、test_changes、deviations[]。不自动提交。

使用[业务模板](templates/modification.json)与[输出结构](schemas/modification.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需路径预算、禁止变更类型、测试审批策略及受保护文件。新依赖、Schema迁移、权限放开、事务边界改变默认扩围并升级风险。

## 按需参考

- [implementation-guardrails](references/implementation-guardrails.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。
