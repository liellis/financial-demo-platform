# implementation-guardrails

先确认Spec/风险/范围/上下文/保护和有效Red，保存客户未提交diff。一次最小行为变更，不顺便重构、改依赖、生产配置、权限或事务边界。

修改后用实际Git diff核对路径和预算。删断言/用例、@Disabled/@Ignore和skipTests需独立说明；不能以改Oracle/吞异常/Mock subject造Green。扩围和升风险停止并提交具体修订。
