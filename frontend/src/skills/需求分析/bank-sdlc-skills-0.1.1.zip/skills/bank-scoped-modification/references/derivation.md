# S14 派生记录

- [skills/executing-plans/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/executing-plans/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [src/core/templates/workflows/apply-change.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/apply-change.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S14-D01：删除隐式 worktree、自动 commit 和 required subagent；使用客户当前授权工作区。
- S14-D02：新增前置证据：已确认 Spec/范围、有效风险、保护基线及需要的有效 Red。
- S14-D03：新增 diff 范围与用户修改保护；禁止删除测试、关闭检查或改预期来制造 Green。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
