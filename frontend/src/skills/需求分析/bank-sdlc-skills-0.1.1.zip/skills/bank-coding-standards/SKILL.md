---
name: bank-coding-standards
description: 编码规范应用；将客户Java、交易、金额、日期及安全规范筛选成当前变更适用的检查项，保留来源和冲突。
metadata:
  skill-id: "S13"
  version: "0.1.1"
---

# 编码规范应用

将客户Java、交易、金额、日期及安全规范筛选成当前变更适用的检查项，保留来源和冲突。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取客户规范、项目已有 Checkstyle/SpotBugs/测试配置及允许版本；先尊重客户现行规则。
2. 对本任务筛选适用规则，标出冲突、过期或无法确定来源的项。
3. 为金额精度、日期源、事务传播、异常码、日志脱敏及依赖使用生成具体检查卡。
4. 明确可调用的既有扫描任务与报告格式；未安装的扫描器不自动引入项目。
5. 检查拟改代码与规则，新增依赖、事务或权限变化提交专门审查。
6. 给 S14 的实现约束和 S17 的审查列表；不顺手统一格式、重命名或重构未涉及代码。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类PolicyRefCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`standards.json/md`；rules[{rule_id,source,version,severity,applicability,check_method}]、conflicts[]、scanner_requirements[]。缺客户批准阈值不自行填值。

使用[业务模板](templates/standards.json)与[输出结构](schemas/standards.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需编码规范、日志规范、交易注解、自定义数据类型及扫描豁免流程。规则冲突先升级确认，模型不能按个人偏好取舍。

## 按需参考

- [java-bank-rules](references/java-bank-rules.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
