import org.json.*;import java.util.*;
public final class PolicyRefCheck{
 public static void main(String[] a){Support.mainEntry(a,"S13",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));JSONArray rules=p.getJSONArray("rules");s.ids(rules,"rule_id","STANDARD_ID");
  for(Object x:rules){JSONObject r=(JSONObject)x;Support.requireFields(s,r,"source","version","severity","applicability","check_method","owner");
   s.check("METHOD_KIND",Arrays.asList("SCRIPT","SCANNER","MODEL_REVIEW","HUMAN_REVIEW").contains(r.getString("check_method")),"Review method is explicit");
   if(!Support.present(r,"approval_ref"))s.confirm("STANDARD_APPROVAL","Mandatory customer rule needs approved source");}
  if(Support.arr(p,"conflicts").length()>0)s.block("STANDARD_CONFLICT","Conflicting standards need customer decision");
 });}
}
