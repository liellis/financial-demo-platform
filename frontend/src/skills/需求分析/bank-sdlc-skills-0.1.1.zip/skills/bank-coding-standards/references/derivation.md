# S13 派生记录

- [templates/commands/constitution.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/constitution.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。

- S13-D01：保留规则追溯，删除自动更新宪章；每条规则标来源、适用目录、强制/建议和 owner。
- S13-D02：新增 Java/Spring/SQL/日志/金额/日期/事务清单及客户扫描结果映射。
- S13-D03：区分可确定检查与需要人/模型审查的语义，禁止用正则声称证明线程安全或事务正确。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
