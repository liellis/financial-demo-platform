# 编码规范应用

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`applicable-standards.json/md`；rules[{rule_id,source,version,severity,applicability,check_method}]、conflicts[]、scanner_requirements[]。缺客户批准阈值不自行填值。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
