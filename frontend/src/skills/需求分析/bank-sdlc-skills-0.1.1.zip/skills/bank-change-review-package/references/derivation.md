# S20 派生记录

- [skills/verification-before-completion/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/verification-before-completion/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [skills/finishing-a-development-branch/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/finishing-a-development-branch/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S20-D01：删除 merge/push/discard 行为，仅汇总候选变更与证据。
- S20-D02：新增工件摘要、快照一致性、必需检查状态及残余风险矩阵。
- S20-D03：将回退“方案”和“已演练结果”分字段，避免文档存在即宣称恢复可用。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
