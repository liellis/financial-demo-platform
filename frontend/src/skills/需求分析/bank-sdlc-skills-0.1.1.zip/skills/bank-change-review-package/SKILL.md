---
name: bank-change-review-package
description: 变更审查包；汇总同一候选快照的规格、风险、差异和验证证据，生成客户reviewer材料；不自动批准合并。
metadata:
  skill-id: "S20"
  version: "0.1.1"
---

# 变更审查包

汇总同一候选快照的规格、风险、差异和验证证据，生成客户reviewer材料；不自动批准合并。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取最终 diff、Spec、风险、范围、S16/S17/S18/S19及客户审查要求。
2. ReviewPackCheck 核对来源快照、摘要及缺失项；不自动把过期结果改为当前。
3. 汇总问题、具体行为变化、不变项、实际验证、未覆盖、flaky 与环境限制。
4. 写部署/数据/回退前提，数据不可逆和未演练项显著呈现。
5. 生成 reviewer 清单及关键业务/QA需复核项，列所有豁免来源和仍然存在的风险。
6. 给出可复核结论：材料完整/不完整、阻塞清单；“材料完整”不等于已获合并授权。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类ReviewPackCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

本目录scripts/snapshot.sh可计算快照，请求roots数组，须覆盖相关源码/测试/构建与资源。

## 输出与验证

`review/review-package.md`、`review-manifest.json`；artifact_hashes、candidate_snapshot、verification_matrix、open_risks、rollback_plan_ref、rollback_test_ref、required_reviewers、blocking_items。供人审及 S21使用。

使用[业务模板](templates/review-package.json)与[输出结构](schemas/review-package.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需变更委员会/技术/业务/QA材料要求、工单引用、保留策略及脱敏边界。正式批准与审计仍进入客户已有系统。

## 按需参考

- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。

0.1.1已收紧来源、类型和范围检查；调用前读取[工件约定中的运行契约修订](references/contracts.md)。旧请求缺字段会阻断，不能补写批准。

清单非运行项格式见[审查证据项样例](templates/review-item.example.json)。
