import org.json.*;import java.util.*;import java.nio.file.*;import java.io.*;import java.util.concurrent.*;
final class GitDiff {
 static String fingerprint(Support s,String base)throws Exception{
  TreeMap<String,String> files=new TreeMap<String,String>();
  for(Object x:changed(s,base)){
   String path=((JSONObject)x).getString("path");
   if(path.startsWith(".sdlc/")||path.startsWith(".opencode/skills/"))continue;
   Path p=Support.inside(s.root,path,false);files.put(path,Files.exists(p)?Support.sha(s.file(path)):"DELETED");
  }
  StringBuilder b=new StringBuilder(base+"\n");
  for(Map.Entry<String,String> e:files.entrySet())b.append(e.getKey()).append('\0').append(e.getValue()).append('\n');
  return Support.sha(b.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
 }
 static byte[] git(Support s,String... args)throws Exception{
  List<String> cmd=new ArrayList<String>(Arrays.asList("git","-C",s.root.toString()));cmd.addAll(Arrays.asList(args));
  ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);pb.environment().put("GIT_OPTIONAL_LOCKS","0");pb.environment().put("GIT_TERMINAL_PROMPT","0");
  Process p=pb.start();ByteArrayOutputStream b=new ByteArrayOutputStream();final IOException[] fail={null};
  Thread t=new Thread(()->{try(InputStream in=p.getInputStream()){byte[] buf=new byte[8192];int n;
   while((n=in.read(buf))!=-1){if(b.size()+n>2*1024*1024)throw new IOException("Git output limit");b.write(buf,0,n);}}
   catch(IOException e){fail[0]=e;p.destroyForcibly();}});t.setDaemon(true);t.start();
  if(!p.waitFor(20,TimeUnit.SECONDS)){p.destroyForcibly();throw new IOException("Git timeout");}t.join(2000);
  if(t.isAlive()||fail[0]!=null||p.exitValue()!=0)throw new IOException("Git command failed");
  return b.toByteArray();
 }
 static JSONArray changed(Support s,String base)throws Exception{
  if(!base.matches("[0-9a-fA-F]{40}|[0-9a-fA-F]{64}"))throw new IOException("Commit SHA required");
  String raw=new String(git(s,"diff","--no-ext-diff","--no-textconv","--no-renames","--numstat","-z",base,"--"),java.nio.charset.StandardCharsets.UTF_8);
  LinkedHashMap<String,JSONObject> rows=new LinkedHashMap<String,JSONObject>();
  for(String rec:raw.split("\u0000")){if(rec.isEmpty())continue;String[] f=rec.split("\t",3);if(f.length!=3)throw new IOException("Invalid Git record");
   rows.put(f[2],new JSONObject().put("path",f[2]).put("added",f[0].equals("-")?JSONObject.NULL:Integer.valueOf(f[0]))
    .put("deleted",f[1].equals("-")?JSONObject.NULL:Integer.valueOf(f[1])).put("tracked",true));}
  String untracked=new String(git(s,"ls-files","--others","--exclude-standard","-z"),java.nio.charset.StandardCharsets.UTF_8);
  for(String path:untracked.split("\u0000")){if(path.isEmpty()||path.startsWith(".sdlc/changes/")||path.startsWith(".opencode/skills/"))continue;
   Path file=s.file(path);byte[] b=Support.bounded(file,2*1024*1024);boolean binary=false;for(byte c:b)if(c==0){binary=true;break;}
   int lines=b.length==0?0:1;for(byte c:b)if(c=='\n')lines++;if(b.length>0&&b[b.length-1]=='\n')lines--;
   rows.put(path,new JSONObject().put("path",path).put("added",binary?JSONObject.NULL:lines).put("deleted",0).put("tracked",false));}
  JSONArray result=new JSONArray();for(JSONObject r:rows.values())if(!r.getString("path").startsWith(".sdlc/changes/"))result.put(r);
  return result;
 }
 static void scope(Support s,JSONObject scope)throws Exception{
  for(String key:Arrays.asList("allowed_symbols","allowed_change_types")){
   if(scope.has(key)&&(!(scope.opt(key) instanceof JSONArray)||scope.getJSONArray(key).length()>0))
    s.block("SEMANTIC_SCOPE_REQUIRES_REVIEW","Symbol/change-type restrictions need the customer semantic review path; this version must not silently ignore them");
  }
  JSONArray rows=changed(s,scope.getString("base_commit")),allow=scope.getJSONArray("allow_paths"),deny=scope.getJSONArray("deny_paths");
  int lines=0;JSONObject baseline=scope.optJSONObject("baseline_user_files");
  for(Object x:rows){JSONObject r=(JSONObject)x;String path=r.getString("path");
   Path resolved=Support.inside(s.root,path,false);
   boolean unchangedUser=baseline!=null&&baseline.has(path)&&Files.isRegularFile(resolved)&&Support.sha(resolved).equals(baseline.getString(path));
   if(unchangedUser){r.put("baseline_user_change",true);continue;}
   boolean runtime=path.startsWith(".git/")||path.startsWith(".opencode/")||path.startsWith(".sdlc/profiles/");
   s.check("SCOPE_PATH",!runtime && Support.anyGlob(path,allow)&&!Support.anyGlob(path,deny),"Allowed path: "+path);
   if(r.isNull("added")||r.isNull("deleted"))s.block("BINARY_DIFF","Binary changes require manual scope review");
   else lines+=r.getInt("added")+r.getInt("deleted");
  }
  long count=0;for(Object x:rows)if(!((JSONObject)x).optBoolean("baseline_user_change"))count++;
  s.check("FILE_BUDGET",count<=scope.getInt("max_files"),"Changed-file budget");
  s.check("LINE_BUDGET",lines<=scope.getInt("max_diff_lines"),"Added plus removed line budget");
  s.facts.put("changed_files",rows).put("diff_lines",lines).put("runtime_untracked_exclusions",new JSONArray(Arrays.asList(".sdlc/changes/**",".opencode/skills/**")));
 }
}
