import org.json.*;import org.w3c.dom.*;import java.nio.file.*;import java.util.*;
final class JUnitXmlReader{
 static JSONArray parse(Path path,String module)throws Exception{
  Document d=Support.xml(path);Element root=d.getDocumentElement();
  if(!Arrays.asList("testsuite","testsuites").contains(root.getTagName()))throw new java.io.IOException("Not JUnit XML");
  JSONArray cases=new JSONArray();Set<String> ids=new HashSet<String>();
  for(Element t:Support.elements(root,"testcase")){
   String cls=t.getAttribute("classname"),name=t.getAttribute("name");
   if(cls.isEmpty()||name.isEmpty())throw new java.io.IOException("Test identity missing");
   String id=module+"::"+cls+"#"+name;
   if(!ids.add(id))throw new java.io.IOException("Duplicate test identity requires engine/parameter disambiguation");
   boolean fail=!Support.elements(t,"failure").isEmpty(),err=!Support.elements(t,"error").isEmpty(),skip=!Support.elements(t,"skipped").isEmpty();
   if((fail?1:0)+(err?1:0)+(skip?1:0)>1)throw new java.io.IOException("Conflicting test states");
   String status=err?"ERROR":fail?"FAILED":skip?"SKIPPED":"PASSED";
   String kind="";
   if(fail){String type=Support.elements(t,"failure").get(0).getAttribute("type");
    kind=type.matches(".*(AssertionError|AssertionFailedError|ComparisonFailure).*")?"ASSERTION":"UNCLASSIFIED_FAILURE";}
   cases.put(new JSONObject().put("id",id).put("module",module).put("class_name",cls).put("name",name).put("status",status).put("failure_kind",kind));
  }
  if(cases.length()>50000)throw new java.io.IOException("Test report budget");
  return cases;
 }
 static List<Path> reports(Support s,JSONArray roots)throws Exception{
  List<Path> files=new ArrayList<Path>();Set<Path> seen=new HashSet<Path>();
  for(Object x:roots){Path root=Support.inside(s.root,x.toString(),false);if(!Files.exists(root))continue;
   try(java.util.stream.Stream<Path> st=Files.walk(root,12)){
    Iterator<Path> it=st.iterator();while(it.hasNext()){Path p=it.next();if(Files.isSymbolicLink(p))throw new java.io.IOException("Report symlink");
     if(Files.isRegularFile(p)&&p.getFileName().toString().matches("TEST-.+\\.xml")){
      s.file(s.root.relativize(p).toString());if(!seen.add(p))throw new java.io.IOException("Overlapping report roots");files.add(p);
      if(files.size()>2000)throw new java.io.IOException("Too many reports");
     }}
   }
  }
  Collections.sort(files);return files;
 }
}
