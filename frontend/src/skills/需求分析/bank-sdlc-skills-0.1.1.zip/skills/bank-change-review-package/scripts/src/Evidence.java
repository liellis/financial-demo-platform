import org.json.*;
import java.util.*;
import java.nio.file.*;
import java.io.*;

/** Typed local evidence links. Hashes detect changed inputs, not signer identity. */
final class Evidence {
 static JSONObject result(Support s,String path,String skill,boolean pass)throws Exception {
  JSONObject r=s.json(path);
  s.check("RESULT_VERSION","2.0".equals(r.optString("schema_version")),"Check-result contract version");
  s.check("RESULT_SKILL",skill.equals(r.optString("skill_id")),"Expected checker: "+skill);
  s.bindChange(r.getString("change_id"));
  if(pass)s.check("RESULT_PASS","PASS".equals(r.optString("status")),"Required checker passed");
  r.getJSONObject("facts");r.getJSONObject("input_hashes");
  return r;
 }
 static void inputsCurrent(Support s,JSONObject result)throws Exception {
  JSONObject hashes=result.getJSONObject("input_hashes");
  s.check("RESULT_INPUTS_PRESENT",hashes.length()>0,"Checker retains input hashes");
  for(String path:hashes.keySet()){
   String actual=Support.sha(s.file(path));s.inputHashes.put(path,actual);
   s.check("RESULT_INPUT_CURRENT",actual.equals(hashes.getString(path)),"Checker input unchanged: "+path);
  }
 }
 static JSONObject artifact(Support s,String path,String type)throws Exception {
  JSONObject a=s.json(path);
  s.check("EVIDENCE_TYPE",type.equals(a.optString("artifact_type")),"Expected evidence type: "+type);
  s.check("EVIDENCE_CONTRACT","2.0".equals(a.optString("schema_version"))&&Support.present(a,"artifact_id"),"Version and artifact identity");
  s.check("EVIDENCE_PASS","PASS".equals(a.optString("status")),"Required business artifact is PASS");
  s.bindChange(a.getString("change_id"));a.getJSONObject("payload");return a;
 }
 static String profilePath(String path)throws IOException {
  Path p=Paths.get(path);
  if(p.isAbsolute()||!path.equals(path.replace('\\','/'))||!p.normalize().toString().replace('\\','/').equals(path)||!path.startsWith(".sdlc/profiles/"))throw new IOException("Governed profile path required");
  return path;
 }
 static JSONObject command(JSONObject cfg,String id)throws IOException {
  JSONObject found=null;
  for(Object x:cfg.getJSONArray("commands"))if(((JSONObject)x).getString("id").equals(id)){
   if(found!=null)throw new IOException("Duplicate command id");found=(JSONObject)x;
  }
  if(found==null)throw new IOException("Unknown command");return found;
 }
 static JSONObject risk(Support s,String path)throws Exception {
  JSONObject r=result(s,path,"S06",true);inputsCurrent(s,r);JSONObject f=r.getJSONObject("facts");
  s.bindChange(f.getString("change_id"));
  s.check("RISK_POLICY_CURRENT",Support.sha(s.file(profilePath(f.getString("policy_path")))).equals(f.getString("policy_sha256")),"Risk profile unchanged");
  s.check("RISK_DIFF_CURRENT",GitDiff.fingerprint(s,f.getString("base_commit")).equals(f.getString("diff_digest")),"Risk belongs to current actual diff");
  s.check("RISK_MODIFY",Support.strings(Support.stringArray(f,"allowed_actions")).contains("MODIFY"),"Current PASS risk permits MODIFY");
  return f;
 }
 static void linkedArtifact(Support s,JSONObject checked,String path)throws Exception {
  JSONObject hashes=checked.getJSONObject("input_hashes");
  s.check("CHECKER_ARTIFACT_LINK",hashes.has(path)&&Support.sha(s.file(path)).equals(hashes.optString(path)),"Checker validated the exact artifact revision");
  inputsCurrent(s,checked);
 }
}
