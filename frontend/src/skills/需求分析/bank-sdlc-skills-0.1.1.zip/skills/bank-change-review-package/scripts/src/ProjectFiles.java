import org.json.*;import java.nio.file.*;import java.util.*;import java.util.stream.*;
final class ProjectFiles{
 static void approvedRoots(Support s,JSONObject cmd,JSONArray roots,JSONArray production)throws Exception{
  Set<String> full=Support.strings(roots),prod=Support.strings(production);
  JSONArray required=Support.stringArray(cmd,"snapshot_roots"),requiredProd=Support.stringArray(cmd,"production_roots");
  if(required.length()==0||requiredProd.length()==0)throw new java.io.IOException("Approved roots required");
  if(!full.equals(Support.strings(required))||!prod.equals(Support.strings(requiredProd)))throw new java.io.IOException("Request roots must match approved classification");
  Set<String> files=Support.strings(expand(s,roots));
  if(!files.containsAll(Support.strings(expand(s,production))))throw new java.io.IOException("Production missing from full snapshot");
 }
 static void diffCovered(Support s,JSONArray roots,String base)throws Exception{
  Set<String> included=Support.strings(expand(s,roots));
  for(Object x:GitDiff.changed(s,base)){
   String name=((JSONObject)x).getString("path");
   if(name.startsWith(".sdlc/")||name.startsWith(".opencode/skills/"))continue;
   Path file=Support.inside(s.root,name,false);boolean covered=false;
   for(Object r:roots){Path root=Support.inside(s.root,r.toString(),false);covered|=file.equals(root)||file.startsWith(root);}
   if(Files.exists(file))covered&=included.contains(name);
   s.check("SNAPSHOT_DIFF_COVERED",covered,"Actual changed/untracked file belongs to snapshot roots and expanded files: "+name);
  }
 }
 static JSONArray expand(Support s,JSONArray roots)throws Exception{
  if(roots.length()==0)throw new java.io.IOException("Explicit snapshot roots required");
  Set<String> paths=new TreeSet<String>();
  for(Object x:roots){
   Path p=Support.inside(s.root,x.toString(),false);
   if(!Files.exists(p)||p.equals(s.root))throw new java.io.IOException("Explicit source/build root required");
   if(Files.isDirectory(p)){
    try(Stream<Path> stream=Files.walk(p,30)){
     Iterator<Path> it=stream.iterator();
     while(it.hasNext()){
      Path f=it.next();String rel=s.root.relativize(f).toString().replace('\\','/');
      if(Files.isSymbolicLink(f))throw new java.io.IOException("Snapshot symlink");
      if(Files.isRegularFile(f)){
       if(rel.matches("(^|.*/)(target|build|\\.git|\\.sdlc|\\.opencode|node_modules|\\.gradle)/.*"))continue;
       s.file(rel);paths.add(rel);
       if(paths.size()>10000)throw new java.io.IOException("Snapshot file budget");
      }
     }
    }
   }else {s.file(x.toString());paths.add(s.root.relativize(p).toString().replace('\\','/'));}
  }
  if(paths.isEmpty())throw new java.io.IOException("Empty snapshot");
  return new JSONArray(paths);
 }
}
