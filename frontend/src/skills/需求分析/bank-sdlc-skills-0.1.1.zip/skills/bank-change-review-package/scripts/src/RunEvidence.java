import org.json.*;import java.util.*;
final class RunEvidence{
 static JSONObject load(Support s,String path,boolean current)throws Exception{
  JSONObject wrapper=s.json(path),r;
  if(wrapper.has("facts")){
   s.check("RUN_CHECKER","S16".equals(wrapper.optString("skill_id"))&&"2.0".equals(wrapper.optString("schema_version")),"Run comes from S16");
   s.check("RUN_STATUS",Arrays.asList("PASS","FAIL").contains(wrapper.optString("status")),"Run is an actual success or test/build failure, not invalidated evidence");
   s.bindChange(wrapper.getString("change_id"));r=wrapper.getJSONObject("facts").getJSONObject("run");
  }else r=wrapper;
  s.bindChange(r.getString("change_id"));
  String profile=Evidence.profilePath(r.getString("profile_path"));JSONObject cfg=s.json(profile);
  JSONObject cmd=Evidence.command(cfg,r.getString("command_id"));
  s.check("RUN_APPROVED_PROFILE",Support.present(cfg,"owner")&&Support.present(cfg,"approval_ref"),"Run uses an approved profile");
  ProjectFiles.approvedRoots(s,cmd,r.getJSONArray("snapshot_roots"),r.getJSONArray("production_roots"));
  s.check("RUN_ID",Support.present(r,"run_id")&&Support.present(r,"command_id"),"Run identity exists");
  s.check("RUN_STABLE",r.getJSONObject("before_snapshot").getString("digest").equals(r.getJSONObject("after_snapshot").getString("digest")),"Run input was stable");
  s.check("RUN_CLEANUP",!r.getBoolean("cleanup_unverified"),"No unverified timed-out process");
  if(current){
   ProjectFiles.diffCovered(s,r.getJSONArray("snapshot_roots"),r.getString("base_commit"));
   JSONObject now=s.snapshot(ProjectFiles.expand(s,r.getJSONArray("snapshot_roots")));
   s.check("RUN_CURRENT",now.similar(r.getJSONObject("after_snapshot")),"Run snapshot matches current declared roots, including newly added files");
  }
  s.check("RUN_PROFILE",Support.sha(s.file(profile)).equals(r.getString("profile_sha256")),"Run command profile is unchanged");
  JSONArray raw=r.getJSONArray("raw_reports"),actual=new JSONArray();Set<String> ids=new HashSet<String>();
  s.check("RUN_REPORTS",raw.length()>0,"Original run reports exist");
  for(Object x:raw){JSONObject report=(JSONObject)x;
   String reportPath=report.getString("path"),hash=Support.sha(s.file(reportPath));s.inputHashes.put(reportPath,hash);
   s.check("RUN_REPORT_HASH",hash.equals(report.getString("sha256")),"Raw report is unchanged");
   for(Object c:JUnitXmlReader.parse(s.file(report.getString("path")),report.getString("module"))){
    if(!ids.add(((JSONObject)c).getString("id")))throw new java.io.IOException("Duplicate case across reports");
    actual.put(c);
   }
  }
  s.check("RUN_NORMALIZATION",actual.similar(r.getJSONArray("cases")),"Normalized results match original report instances");
  s.check("RUN_NONEMPTY",actual.length()>0,"Run has reported instances");
  int passed=0,failed=0,errors=0,skipped=0;
  for(Object x:actual){String state=((JSONObject)x).getString("status");
   if(state.equals("PASSED"))passed++;if(state.equals("FAILED"))failed++;if(state.equals("ERROR"))errors++;if(state.equals("SKIPPED"))skipped++;}
  s.check("RUN_COUNTS",passed==r.getInt("passed")&&failed==r.getInt("failed")&&errors==r.getInt("errors")&&skipped==r.getInt("skipped")&&actual.length()-skipped==r.getInt("executed_count"),"Summary counters match original cases");
  JSONArray expected=r.getJSONArray("expected_test_ids");s.check("RUN_EXPECTED",expected.length()>0,"Expected instances are recorded");
  for(Object id:expected)s.check("RUN_EXPECTED_EXECUTED",ids.contains(id.toString()),"Expected instance actually executed: "+id);
  return r;
 }
 static Map<String,JSONObject> cases(JSONObject r){
  Map<String,JSONObject> out=new LinkedHashMap<String,JSONObject>();for(Object x:r.getJSONArray("cases")){JSONObject c=(JSONObject)x;out.put(c.getString("id"),c);}return out;
 }
 static boolean green(JSONObject r){
  if(r.getJSONArray("cases").length()==0)return false;
  for(Object x:r.getJSONArray("cases"))if(!((JSONObject)x).getString("status").equals("PASSED"))return false;
  return r.getInt("exit_code")==0&&!r.optBoolean("flaky")&&!r.optBoolean("cleanup_unverified")
   &&r.getInt("failed")==0&&r.getInt("errors")==0&&r.getInt("skipped")==0&&r.getInt("executed_count")>0;
 }
}
