public final class SnapshotCapture{
 public static void main(String[] a){Support.mainEntry(a,"SNAPSHOT",s->{
  org.json.JSONArray paths=ProjectFiles.expand(s,s.request.getJSONArray("roots"));
  s.facts.put("snapshot",s.snapshot(paths)).put("scope","DECLARED_ROOTS");
 });}
}
