import org.json.*;import java.util.*;
public final class ReviewPackCheck{
 public static void main(String[] a){Support.mainEntry(a,"S20",s->{
  JSONObject p=Support.payload(s.artifact("artifact","review_package")),cfg=s.json(Evidence.profilePath(s.request.getString("review_policy")));
  if(!Support.present(cfg,"approval_ref"))s.confirm("REVIEW_POLICY","Customer review requirements need approved source");
  JSONObject candidate=p.getJSONObject("candidate_snapshot");String digest=candidate.getString("digest");
  s.check("REVIEW_CANDIDATE",s.currentSnapshot(candidate),"Review package candidate is current");
  Set<String> found=new HashSet<String>(),paths=new HashSet<String>();boolean actualCandidate=false;
  for(Object x:p.getJSONArray("artifacts")){
   JSONObject item=(JSONObject)x;String path=item.getString("path"),type=item.getString("type");
   s.check("REVIEW_UNIQUE_SOURCE",paths.add(s.file(path).toString()),"Each source can only be counted once");
   s.check("REVIEW_ARTIFACT_HASH",Support.sha(s.file(path)).equals(item.getString("sha256")),"Artifact hash");
   if(type.equals("test_run")){
    Evidence.result(s,path,"S16",true);JSONObject r=RunEvidence.load(s,path,true);
    s.check("REVIEW_TEST_GREEN",RunEvidence.green(r),"Tests are green");
    boolean same=candidate.similar(r.getJSONObject("after_snapshot"));actualCandidate|=same;
    s.check("REVIEW_RUN_CANDIDATE",same,"Actual run validates the complete review candidate");
   }else{
    if(!Arrays.asList("quality_review","traceability").contains(type))throw new IllegalArgumentException("Unsupported required evidence type");
    JSONObject artifact=Evidence.artifact(s,path,type),payload=artifact.getJSONObject("payload");
    s.check("REVIEW_SNAPSHOT_LINK",digest.equals(artifact.optString("source_snapshot")),"Artifact bound to candidate snapshot");
    String checkPath=item.getString("check_result_path");
    s.check("REVIEW_CHECK_HASH",Support.sha(s.file(checkPath)).equals(item.getString("check_result_sha256")),"Corresponding checker revision");
    JSONObject checked=Evidence.result(s,checkPath,type.equals("quality_review")?"S17":"S18",true),facts=checked.getJSONObject("facts");
    s.check("REVIEW_CHECK_CANDIDATE",digest.equals(facts.optString("candidate_digest")),"Checker belongs to candidate");
    if(type.equals("quality_review"))Evidence.linkedArtifact(s,checked,path);
    else{
     Evidence.inputsCurrent(s,checked);
     s.check("REVIEW_TRACE_CHECK",checkPath.equals(payload.optString("check_result_ref")),"Trace artifact names corresponding checker");
     for(String key:facts.keySet())s.check("REVIEW_TRACE_FACT",payload.has(key)&&new JSONObject().put("v",facts.get(key)).similar(new JSONObject().put("v",payload.get(key))),"Trace facts match checker: "+key);
    }
   }
   found.add(type);
  }
  s.check("REVIEW_ACTUAL_CANDIDATE",actualCandidate,"Review includes an actual current candidate run");
  JSONArray required=Support.stringArray(cfg,"required_artifact_types");
  s.check("REVIEW_POLICY_NONEMPTY",required.length()>0,"Required evidence policy is nonempty");
  for(Object t:required)s.check("REVIEW_REQUIRED",found.contains(t.toString()),"Required artifact type: "+t);
  if(Support.arr(p,"blocking_items").length()>0)s.block("REVIEW_BLOCKERS","Open blockers remain");
  Support.requireFields(s,p,"rollback_plan","required_reviewers");
  s.facts.put("material_complete_only",true).put("merge_approved",false).put("rollback_exercised",Support.present(p,"rollback_test_ref")).put("candidate_digest",digest);
 });}
}
