# 仓库理解

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`repo-profile.json/md`；字段含 modules[]、source_roots[]、build_files[]、declared_toolchain、entry_candidates[]、test_roots[]、evidence[]、unresolved[]。S02/S04/S13 使用其版本和来源。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
