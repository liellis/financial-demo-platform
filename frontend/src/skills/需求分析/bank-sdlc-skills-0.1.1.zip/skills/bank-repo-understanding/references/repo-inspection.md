# repo-inspection

按模块采集：build文件、source/test根、入口注册、DAO/SQL、外部系统和现有测试任务。每条记录path、symbol、source_kind、sha256；读取配置名称时不展开秘密。

Maven只安全读取POM声明：module相对当前POM，父工程和属性继承未解析时unknown。Gradle静态文本仅线索，不为画像执行脚本。先取得最小可构建命令及受控环境，再由测试执行任务验证。
