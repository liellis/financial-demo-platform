# bank-entry-types

API：路由注解/显式注册；交易：客户交易码映射；批量：Job/调度/日终配置；消息：topic/队列与listener绑定；数据：Mapper namespace及statement；外部：RPC/HTTP适配配置。

核心操作分类来自客户关键业务清单，包名或类名只能生成候选。将异步、批量重跑和对账入口单列，避免误画同一同步事务。
