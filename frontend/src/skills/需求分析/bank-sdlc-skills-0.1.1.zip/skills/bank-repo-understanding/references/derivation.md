# S01 派生记录

- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S01-D01：将 F15 的开放探索改写为“目录→构建→入口→基础设施→待确认”的固定清单，删除 OpenSpec 命令和自由扩展范围的指令。
- S01-D02：新增 POM 的安全 XML 读取、Gradle 文件静态线索识别；禁止仅为画像执行任意 Gradle 配置脚本。parent、动态插件、外部属性未解析时保留 unknown。
- S01-D03：新增银行入口分类：联机 API、交易服务、日终/批量、消息消费、账务/支付适配、数据访问；分类是候选，附 owner 确认入口。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
