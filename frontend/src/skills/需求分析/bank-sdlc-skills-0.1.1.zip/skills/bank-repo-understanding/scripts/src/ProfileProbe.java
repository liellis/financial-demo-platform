import org.json.*;import java.nio.file.*;import org.w3c.dom.*;
public final class ProfileProbe {
 public static void main(String[] a){Support.mainEntry(a,"S01",s->{
  JSONArray files=s.request.getJSONArray("build_files"), modules=new JSONArray(), builds=new JSONArray();
  s.check("BUILD_FILES",files.length()>0,"Build file list is explicit");
  for(Object x:files){String path=x.toString();Path p=s.file(path);
   JSONObject b=new JSONObject().put("path",path).put("sha256",Support.sha(p));
   if(p.getFileName().toString().equals("pom.xml")){
    Element e=Support.xml(p).getDocumentElement();
    s.check("POM_ROOT",e.getTagName().equals("project"),"POM project root");
    b.put("tool","maven").put("artifact_id",Support.childText(e,"artifactId"))
      .put("declared_version",Support.childText(e,"version"));
    for(Element m:Support.elements(e,"module")){
     String module=m.getTextContent().trim();
     Path candidate=p.getParent().resolve(module).normalize();
     s.check("MODULE_PATH",candidate.startsWith(s.root) && Files.isDirectory(candidate),"Declared module exists inside root");
     modules.put(new JSONObject().put("path",s.root.relativize(candidate).toString().replace('\\','/')).put("pom_source",path));
    }
    if(Support.elements(e,"parent").size()>0)s.unknown("PARENT_RESOLUTION","Parent/inherited values are not resolved by static POM reading");
   }else if(p.toString().endsWith(".gradle")||p.toString().endsWith(".gradle.kts")){
    b.put("tool","gradle");s.unknown("GRADLE_DYNAMIC","Gradle is not executed; dynamic model and plugin versions need project confirmation");
   }else {s.block("BUILD_KIND","Unsupported build filename");}
   builds.put(b);
  }
  s.facts.put("build_files",builds).put("modules",modules).put("source_kind","STATIC_DECLARATIONS");
 });}
}
