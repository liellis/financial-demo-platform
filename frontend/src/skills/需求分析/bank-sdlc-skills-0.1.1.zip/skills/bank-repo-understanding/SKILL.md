---
name: bank-repo-understanding
description: 仓库理解；在首次接触或画像过期的Java仓库中，建立模块、构建、入口与测试资产的证据画像；不修改业务代码。
metadata:
  skill-id: "S01"
  version: "0.1.1"
---

# 仓库理解

在首次接触或画像过期的Java仓库中，建立模块、构建、入口与测试资产的证据画像；不修改业务代码。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 输入项目根、允许扫描目录、基线提交及客户已有架构资料；首先保存工作区状态，拒绝扫描项目根外路径。
2. 用宿主文件列表读取构建、模块、源码根、测试根、配置文件名；不读取凭据文件内容、不遍历 target/build。
3. 运行本项 ProfileProbe，仅提取模块路径、声明版本、依赖坐标、构建类型和文件摘要；版本继承未解不猜测。
4. 模型从限定源码中识别 Spring 启动、Controller、Job、Listener 和 Mapper，逐项附路径及符号。
5. 将显式配置事实与命名推测分开，列关键业务候选、测试缺口和后续定位入口。
6. 产出画像；需要运行构建才能确认的插件/环境状态写“未执行”，不生成构建成功结论。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类ProfileProbe。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`repo-profile.json/md`；字段含 modules[]、source_roots[]、build_files[]、declared_toolchain、entry_candidates[]、test_roots[]、evidence[]、unresolved[]。S02/S04/S13 使用其版本和来源。

使用[业务模板](templates/repo-profile.json)与[输出结构](schemas/repo-profile.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需提供模块别名、核心交易/账务/批量目录和禁读路径。只有部分源码或构建父工程缺失时 coverage_scope=PARTIAL、status=UNKNOWN，不能声称全仓理解。

## 按需参考

- [repo-inspection](references/repo-inspection.md)：对应步骤判断。
- [bank-entry-types](references/bank-entry-types.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
