# impact-checklist

逐项检查：签名/DTO/null空串零值/错误码/序列化，SQL/索引/迁移，配置默认/消息契约，重试/幂等/批量窗口/对账，部署并存及数据回退。每项写有影响、未知或有依据不适用。

分direct、dependent、business_candidates，附reason/evidence/BR或AC/verification/owner。没有反向关系不能断言零消费者；关键操作未知时提高人工检查范围。
