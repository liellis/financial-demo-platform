# S05 派生记录

- [src/core/templates/workflows/explore.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/explore.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。
- [templates/commands/analyze.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/analyze.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。

- S05-D01：新增三层影响：直接修改点、证据支持的依赖点、需人工核实的业务影响；禁止混为确定列表。
- S05-D02：新增 DTO/错误码/数据库/配置/批量/消息影响检查；新增规则及 AC 的影响关联。
- S05-D03：新增图不完整时的保守扩展规则，为 S19 提供“未知覆盖”信号，而不是输出零影响。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
