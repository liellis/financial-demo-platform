import org.json.*;import java.util.*;
public final class ImpactRefCheck{
 public static void main(String[] a){Support.mainEntry(a,"S05",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));int n=0;
  for(String key:Arrays.asList("direct","dependent","business_candidates")){
   JSONArray rows=p.getJSONArray(key);s.ids(rows,"id","IMPACT_ID_"+key);s.evidenceRows(rows,"evidence");
   for(Object x:rows)Support.requireFields(s,(JSONObject)x,"reason","verification");n+=rows.length();
  }
  s.check("DIRECT_IMPACT",p.getJSONArray("direct").length()>0,"Direct impact is explicit");
  if(Support.arr(p,"unknowns").length()>0)s.unknown("IMPACT_INCOMPLETE","Unknown dependencies are not zero impact");
  s.facts.put("impact_points",n).put("completeness","LIMITED_TO_EVIDENCE");
 });}
}
