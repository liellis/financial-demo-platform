---
name: bank-change-impact
description: 变更影响分析；对拟议变更或实际diff分析直接、依赖及业务影响，列兼容性、验证需求与未知消费者。
metadata:
  skill-id: "S05"
  version: "0.1.1"
---

# 变更影响分析

对拟议变更或实际diff分析直接、依赖及业务影响，列兼容性、验证需求与未知消费者。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 输入需求草案或 Spec、S02/S03/S04、基线及拟改符号/实际 diff；区分规划影响和实施后影响。
2. 枚举直接文件与符号，查上游调用、下游数据和接口消费者；无反向图时用受限搜索。
3. 检查字段/签名/异常/序列化、SQL/索引/迁移、配置默认值及消息契约。
4. 对关键交易、批量重跑、对账、权限和可观测性逐项回答“有影响/无证据/不适用及依据”。
5. 标注部署与数据兼容：新旧版本并存、回退前提、不可逆数据变化仅提出待验证项。
6. 对每个影响点关联 BR/AC、建议验证及 owner，输出分析边界和人工待查项。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类ImpactRefCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`impact.json/md`；direct[]、dependent[]、business_candidates[]、compatibility[]、verification_needs[]、unknowns[]。S06据此定风险，S07收敛修改范围，S19选择回归。

使用[业务模板](templates/impact.json)与[输出结构](schemas/impact.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需关键操作清单、系统间依赖、对账与批量窗口。关键外部消费者未知时不可给“兼容无风险”结论。

## 按需参考

- [impact-checklist](references/impact-checklist.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
