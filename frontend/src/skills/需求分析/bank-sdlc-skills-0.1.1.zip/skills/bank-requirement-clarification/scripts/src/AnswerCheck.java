import org.json.*;import java.util.*;
public final class AnswerCheck{
 public static void main(String[] a){Support.mainEntry(a,"S08",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));JSONArray qs=p.getJSONArray("questions");s.ids(qs,"q_id","QUESTION_ID");
  for(Object x:qs){JSONObject q=(JSONObject)x;String state=q.getString("status");
   Support.requireFields(s,q,"q_id","topic","impact");
   s.check("QUESTION_OPTIONS",q.optJSONArray("options")!=null,"Question options are explicit; free-text questions may use an empty array");
   s.check("QUESTION_ANSWER_FIELDS",q.has("answer")&&q.has("answer_source"),"Unanswered values remain explicit nulls rather than omitted fields");
   s.check("ANSWER_STATE",Arrays.asList("OPEN","ANSWERED","CONFLICT","DEFERRED").contains(state),"Explicit question state");
   if(state.equals("ANSWERED")){Support.requireFields(s,q,"answer","answer_source");s.check("ANSWER_NOT_MODEL",!q.optString("answer_source").equals("MODEL_SUGGESTION"),"Model suggestion is not customer answer");}
   boolean critical=true;
   if(!q.has("critical") || !(q.opt("critical") instanceof Boolean))s.unknown("QUESTION_CRITICALITY_MISSING","Missing/invalid criticality is not implicitly low risk");
   else critical=q.getBoolean("critical");
   if(critical&&!state.equals("ANSWERED"))s.confirm("CRITICAL_QUESTION","Critical question remains unanswered/conflicting");
  }
  s.facts.put("questions_checked",qs.length());
 });}
}
