---
name: bank-requirement-clarification
description: 需求澄清；将银行需求中的金额、业务日、幂等、兼容与验收歧义变成分级问题，记录真实回答及关键未决项。
metadata:
  skill-id: "S08"
  version: "0.1.1"
---

# 需求澄清

将银行需求中的金额、业务日、幂等、兼容与验收歧义变成分级问题，记录真实回答及关键未决项。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取原需求与已有画像/规则；纯需求阶段可没有代码资料，此时标明待代码核对。
2. 将内容分为已明确、可由仓库查证、必须业务确认、超出范围四类，先自行查可查事实。
3. 对影响实现或验收的歧义建立 Q ID，说明为何影响，优先提出关键问题，提供选项及差异。
4. 金额计算明确输入/输出单位和舍入位置；日期明确业务日来源；交易明确重复请求与失败后的行为。
5. 记录实际人类回答及引用，未答继续保持 OPEN；低风险假设可在草案注明，不能静默生效。
6. 汇总确认结果、冲突与阻塞项；关键 Oracle 未确认时不允许 S24 生成“正确预期”。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类AnswerCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`clarifications.json/md`；questions[{q_id,topic,impact,options,status,answer,answer_source}]、assumptions[]、blockers[]。交 S09/S15；关键未决项必须被继承。

使用[业务模板](templates/clarifications.json)与[输出结构](schemas/clarifications.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需岗位与业务 owner、规则来源、术语及允许使用的脱敏材料。不同角色回答冲突时转客户协调，不按最后一条答案自动覆盖。

## 按需参考

- [clarification-taxonomy](references/clarification-taxonomy.md)：对应步骤判断。
- [bank-question-catalog](references/bank-question-catalog.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
