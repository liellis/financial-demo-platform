# clarification-taxonomy

问题字段必须含q_id、topic、critical、impact、status、options、answer和answer_source。critical为布尔，缺失不能默认为低风险。状态OPEN/ANSWERED/CONFLICT/DEFERRED；ANSWERED须有真实回答来源，模型建议不算。

先查代码可确定事实，再向业务确认不能推断的语义；按风险分轮。关键Oracle、金额、日期、交易副作用或生效范围未答时停止实施，保留问题而不默认常见做法。回答冲突交owner。
