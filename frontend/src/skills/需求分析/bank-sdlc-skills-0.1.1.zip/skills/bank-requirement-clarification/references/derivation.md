# S08 派生记录

- [templates/commands/clarify.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/clarify.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。
- [skills/brainstorming/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/brainstorming/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。

- S08-D01：移除 .specify 脚本、分支名约定及隐式 hooks；输入需求由显式文件/受控引用提供。
- S08-D02：将固定问题数量改为按风险分轮；加入金额、时间、幂等、状态、异常、兼容、权限、批量和 Oracle 清单。
- S08-D03：新增回答来源、确认人角色、确认范围和 unresolved 分类；模型建议默认值不能记成客户答案。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
