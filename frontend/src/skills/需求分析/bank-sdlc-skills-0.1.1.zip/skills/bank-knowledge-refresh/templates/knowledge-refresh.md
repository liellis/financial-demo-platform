# 知识刷新

状态：NEEDS_CONFIRMATION

来源ID与摘要：

`knowledge-refresh.json/md` 和 `.sdlc/knowledge/` 下对应条目；baseline_ref、target_commit、updates[]、deleted_sources[]、pending_rules[]、approval_ref。不得修改 bank-policy。

## 已确认事实

## 待确认/未知

## 实际验证与原始结果引用

## 风险与下一步
