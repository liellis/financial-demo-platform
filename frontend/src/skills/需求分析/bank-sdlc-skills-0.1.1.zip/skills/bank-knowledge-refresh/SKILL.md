---
name: bank-knowledge-refresh
description: 知识刷新；按客户确认的代码版本刷新本地画像与来源，保留冲突和已删除条目；不更新银行治理规则。
metadata:
  skill-id: "S22"
  version: "0.1.1"
---

# 知识刷新

按客户确认的代码版本刷新本地画像与来源，保留冲突和已删除条目；不更新银行治理规则。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 输入明确目标提交/工作区候选与旧知识基线；只有客户确认的版本才能更新正式画像。
2. 从 diff 计算受影响的画像、符号、规则观察、链路和测试映射条目。
3. 重读变化来源，更新路径/符号/摘要；删除项保留历史与替代说明。
4. 对代码与批准业务规则冲突建立待确认记录，不自动同步成“业务规则已变更”。
5. KnowledgeCheck 校验引用和目标版本，输出刷新前后 diff；需确认项先进入 pending。
6. 按客户规则批准后写知识文件；未合并候选仅保留变更级预览，不污染正式画像。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类KnowledgeCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`knowledge-update.json/md` 和 `.sdlc/knowledge/` 下对应条目；baseline_ref、target_commit、updates[]、deleted_sources[]、pending_rules[]、approval_ref。不得修改 bank-policy。

使用[业务模板](templates/knowledge-update.json)与[输出结构](schemas/knowledge-update.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需知识 owner、正式版本定义、保留/过期策略和敏感资料范围。目标提交不明或存在未解决冲突时只产出预览。

## 按需参考

- [knowledge-lifecycle](references/knowledge-lifecycle.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
