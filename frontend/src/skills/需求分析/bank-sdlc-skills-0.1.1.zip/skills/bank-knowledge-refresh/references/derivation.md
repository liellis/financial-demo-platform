# S22 派生记录

- [src/core/templates/workflows/sync-specs.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/sync-specs.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S22-D01：删除 OpenSpec CLI、归档命令及直接覆盖主规格；改为显式目标提交与变更集。
- S22-D02：新增源版本、知识条目影响、待批准业务规则与过期标记。
- S22-D03：新增“观察事实”和“正式规则”双轨；合并代码不能自动把观察行为晋升为制度。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
