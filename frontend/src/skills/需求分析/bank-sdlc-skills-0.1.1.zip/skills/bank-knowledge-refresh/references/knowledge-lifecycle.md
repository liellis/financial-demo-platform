# knowledge-lifecycle

输入明确目标commit、旧知识基线、受影响条目及来源。确认版本才更新正式画像；候选只预览。更新路径/符号/hash，删除项保留历史和替代。

代码观察、正式业务规则分轨；冲突pending并指owner，不因代码已合并自动批准业务变更。知识文件限定.sdlc/knowledge，不能修改治理或Skill给自己授权。
