import org.json.*;import java.util.*;
public final class KnowledgeCheck{
 public static void main(String[] a){Support.mainEntry(a,"S22",s->{
  JSONObject p=Support.payload(s.artifact("artifact"));String commit=p.getString("target_commit");
  s.check("KNOWLEDGE_COMMIT",commit.matches("[0-9a-f]{40}|[0-9a-f]{64}"),"Explicit target commit");
  s.check("KNOWLEDGE_CONFIRMED",Support.present(p,"approval_ref")&&p.optBoolean("target_confirmed"),"Confirmed code version");
  JSONArray rows=p.getJSONArray("updates");s.ids(rows,"id","KNOWLEDGE_ID");s.evidenceRows(rows,"evidence");
  for(Object x:rows){JSONObject r=(JSONObject)x;String path=r.getString("knowledge_path");
   s.check("KNOWLEDGE_PATH",path.startsWith(".sdlc/knowledge/")&&!path.contains(".."),"Knowledge updates cannot modify governance or Skill files");
   s.check("KNOWLEDGE_KIND",Arrays.asList("CODE_OBSERVED","DOCUMENTED","PENDING_BUSINESS").contains(r.getString("source_kind")),"Code does not approve business policy");}
  if(Support.arr(p,"conflicts").length()>0)s.confirm("KNOWLEDGE_CONFLICT","Knowledge/business conflicts need owner review");
  s.facts.put("writes_performed",false).put("update_count",rows.length());
 });}
}
