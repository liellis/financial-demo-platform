---
name: bank-spec-validation
description: 规格校验；检查增量规格与澄清记录的结构、引用、确认版本和语义问题；用于实施前规格评审。
metadata:
  skill-id: "S10"
  version: "0.1.1"
---

# 规格校验

检查增量规格与澄清记录的结构、引用、确认版本和语义问题；用于实施前规格评审。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 校验工件类型、版本、来源摘要与快照，旧来源先 STALE。
2. SpecConsistency 检查结构与关联，生成机器可复现的 rule_id 和字段定位。
3. 模型逐 AC 检查是否可测试、是否与其他 AC 冲突、是否遗漏负例或引入未确认范围。
4. 对银行清单逐项标 applicable / not_applicable / unresolved，不能用默认“不适用”跳过。
5. 发现分级：阻塞业务预期、阻塞工程实施、一般改进；每项给依据和可执行修订建议。
6. 输出检查矩阵。程序 PASS 且语义关键问题已关闭，才可进入 S11/S15；不自动替用户补业务答案。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类SpecConsistency。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`spec-validation.json/md`；structural_checks[]、reference_checks[]、semantic_findings[]、blocking_findings[]、coverage_limits[]。修订后重新检查关联来源。

使用[业务模板](templates/spec-validation.json)与[输出结构](schemas/spec-validation.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需客户规格质量规则、必须业务确认的领域和角色。仅脚本 PASS 不等于规格获批，重要规则仍需业务/QA审查。

## 按需参考

- [spec-review-checks](references/spec-review-checks.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
