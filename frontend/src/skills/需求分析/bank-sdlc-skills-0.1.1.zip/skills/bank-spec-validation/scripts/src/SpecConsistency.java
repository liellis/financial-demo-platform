import org.json.*;import java.util.*;
public final class SpecConsistency{
 public static void main(String[] a){Support.mainEntry(a,"S10",s->{
  JSONObject spec=s.artifact("spec"),p=Support.payload(spec);SpecShapeCheck.validate(s,p);
  JSONObject ca=s.artifact("clarifications");JSONObject c=Support.payload(ca);
  s.check("CHANGE_ID",spec.getString("change_id").equals(ca.getString("change_id")),"Spec/clarification change IDs match");
  for(Object x:c.getJSONArray("questions")){JSONObject q=(JSONObject)x;
   if(q.optBoolean("critical"))s.check("CRITICAL_CLOSED","ANSWERED".equals(q.optString("status")),"Critical clarification is answered");}
  s.check("CLARIFICATION_REVISION",p.getString("clarification_artifact_id").equals(ca.getString("artifact_id")),"Confirmed clarification revision matches");
  JSONArray reviews=p.getJSONArray("semantic_reviews");
  s.check("SEMANTIC_REVIEW",reviews.length()>0,"Semantic review is explicit");
  for(Object x:reviews){JSONObject r=(JSONObject)x;Support.requireFields(s,r,"topic","result","review_ref");
   s.check("SEMANTIC_BLOCKER",!r.optString("result").equals("BLOCKING"),"No unresolved semantic blocker");}
 });}
}
