# spec-review-checks

程序检查ID、引用、确认记录、delta和澄清版本；模型/人检查歧义、矛盾、不完整及不可测用语。逐项标applicable/not_applicable/unresolved及依据。

银行重点：舍入点与币种，业务日/自然日，失败回滚与副作用，重复请求，旧合同/接口和Oracle独立性。结构PASS不能关闭业务问题，关键阻塞须有真实确认来源。
