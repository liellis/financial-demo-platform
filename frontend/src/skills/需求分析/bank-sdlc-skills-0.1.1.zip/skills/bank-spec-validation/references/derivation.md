# S10 派生记录

- [templates/commands/analyze.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/analyze.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。
- [src/core/templates/workflows/verify-change.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/verify-change.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S10-D01：移除框架命令，读取本项目 Spec、澄清、规则、影响和范围。
- S10-D02：新增确定性检查：ID 唯一、引用存在、未决项传播、确认版本、delta 合法和不变项覆盖。
- S10-D03：新增银行语义检查：日期/金额歧义、事务与副作用、失败语义、兼容及 Oracle 独立性；结果为审查发现，不伪装程序证明。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
