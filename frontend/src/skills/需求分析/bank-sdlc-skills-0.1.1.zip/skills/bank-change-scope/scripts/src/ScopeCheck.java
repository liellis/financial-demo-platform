public final class ScopeCheck{
 public static void main(String[] a){Support.mainEntry(a,"S07",s->{
  org.json.JSONObject p=Support.payload(s.artifact("scope"));
  s.check("SCOPE_CONFIRMED",Support.confirmed(p),"Scope must have an explicit confirmation reference");
  GitDiff.scope(s,p);
 });}
}
