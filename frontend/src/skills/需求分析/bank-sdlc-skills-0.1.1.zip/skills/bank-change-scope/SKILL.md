---
name: bank-change-scope
description: 修改范围规划；为已确认变更规划允许文件、禁止路径和修改预算，并核对实际Git差异是否需要扩围。
metadata:
  skill-id: "S07"
  version: "0.1.1"
---

# 修改范围规划

为已确认变更规划允许文件、禁止路径和修改预算，并核对实际Git差异是否需要扩围。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取已确认目标、S05 影响、S06 允许动作、当前工作区；未完成澄清时只出草案。
2. 列最小生产改动、测试/资源改动与显式不变项；区分“允许读取”和“允许修改”。
3. 归一化相对路径，拒绝目录穿越、仓外真实路径和逃逸符号链接；deny 优先。
4. 规定每项变更类型，构建依赖、Schema、流水线、权限及测试删除默认需单独审查。
5. 输出计划前差异摘要，记录用户已有修改，不清理、不覆盖。
6. 用 ScopeCheck 对候选 diff 复核；预算超限或新路径返回扩围申请，再由人确认相应修订。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类ScopeCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`change-scope.json/md`；allowed/prohibited paths、symbol constraints、budgets、baseline_diff、owned_changes、confirmation_ref。S14执行，S17检查最终差异；预算是停止条件，不是安全证明。

使用[业务模板](templates/change-scope.json)与[输出结构](schemas/change-scope.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需禁止自动修改的数据库迁移、流水线、证书、生产配置目录。没有范围确认或 L3 不允许修改时，不能出可直接执行的生产写入计划。

## 按需参考

- [scope-policy](references/scope-policy.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
