# S07 派生记录

- [skills/writing-plans/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/writing-plans/SKILL.md)，Commit b36e0829c6d0140e93cfef2ca599b1b07d4a7797。
- [templates/commands/tasks.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/tasks.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。

- S07-D01：保留小任务和验证方法，删除强制 worktree、提交频率和子 Agent 前置。
- S07-D02：新增 allow_paths、deny_paths、allowed_symbols、allowed_change_types、max_files/max_diff_lines、test_paths。
- S07-D03：新增已有用户修改清单与批准扩围的工件修订，不能“发现还需修改”后自动扩大。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
