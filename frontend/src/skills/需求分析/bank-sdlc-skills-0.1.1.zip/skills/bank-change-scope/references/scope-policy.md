# scope-policy

基线为完整commit SHA，计算Git实际diff和未跟踪代码。allow_paths/deny_paths用相对glob，deny优先；不接受目录穿越/符号链接/二进制未审变更。预算统计新增+删除行及文件数。

baseline_user_files保存客户原有未提交内容摘要，仅当前摘要完全一致才排除；同文件混改不能由摘要分清作者，转人工。运行生成的changes工件及未跟踪Skill安装文件不计代码diff，治理权限另控。
