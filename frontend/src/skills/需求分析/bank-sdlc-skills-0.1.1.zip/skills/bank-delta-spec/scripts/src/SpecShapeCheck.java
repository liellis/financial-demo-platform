import org.json.*;import java.util.*;
public final class SpecShapeCheck {
 static void validate(Support s,JSONObject p){
  Support.requireFields(s,p,"goal","baseline_behavior","confirmation");
  Set<String> br=s.ids(p.getJSONArray("business_rules"),"br_id","SPEC_BR"),ac=s.ids(p.getJSONArray("acceptance_criteria"),"ac_id","SPEC_AC");
  s.check("AC_REQUIRED",!ac.isEmpty(),"At least one acceptance criterion");
  s.refs(p.getJSONArray("acceptance_criteria"),"br_ids",br,"AC_BR_LINK");
  for(Object x:p.getJSONArray("acceptance_criteria")){JSONObject c=(JSONObject)x;Support.requireFields(s,c,"given","when","then","oracle_ref");
   if(!c.optBoolean("oracle_confirmed"))s.confirm("AC_ORACLE","Acceptance oracle requires confirmation");}
  for(Object x:p.getJSONArray("deltas")){JSONObject d=(JSONObject)x;String kind=d.getString("type");
   s.check("DELTA_TYPE",Arrays.asList("ADDED","MODIFIED","REMOVED").contains(kind),"Delta kind");
   if(!kind.equals("ADDED"))Support.requireFields(s,d,"previous_rule_id","reason");}
  if(Support.arr(p,"unresolved").length()>0)s.confirm("SPEC_UNRESOLVED","Unresolved requirements cannot disappear");
  s.check("SPEC_CONFIRMATION",Support.confirmed(p.getJSONObject("confirmation")),"Spec version is explicitly confirmed");
  s.facts.put("ac_count",ac.size()).put("br_count",br.size()).put("semantic_correctness","REQUIRES_REVIEW");
 }
 public static void main(String[] a){Support.mainEntry(a,"S09",s->validate(s,Support.payload(s.artifact("artifact"))));}
}
