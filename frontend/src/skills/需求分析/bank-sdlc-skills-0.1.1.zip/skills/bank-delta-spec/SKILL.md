---
name: bank-delta-spec
description: 增量规格生成；为存量系统变更生成ADDED/MODIFIED/REMOVED增量规格、稳定规则及AC、Oracle和不变项。
metadata:
  skill-id: "S09"
  version: "0.1.1"
---

# 增量规格生成

为存量系统变更生成ADDED/MODIFIED/REMOVED增量规格、稳定规则及AC、Oracle和不变项。

## 开始前

缺输入可产草案/缺口清单，不能假造确认或结果。只读任务所需资料；写代码前核对客户允许动作和范围。字段/路径/状态读[工件约定](references/contracts.md)。

## 执行

1. 读取原始需求、S08 澄清、S03 现状、S05 影响；缺现状时对存量行为标 UNKNOWN。
2. 写目标、边界和不做事项，对每个变化声明 delta 类型与所替代的旧规则 ID。
3. 为规则和 AC 赋稳定 ID；每个 AC 用可观察输入、条件、结果描述，包含负例与失败语义。
4. 明确接口/状态/数据变化、异常码、并发/重复请求、配置及部署兼容约束。
5. 写 Oracle 来源，关键业务值附独立依据；删除规则须保留被移除原因及下游影响。
6. 生成 JSON 与 Markdown，等待必要的人类确认，再交 S10；确认后变化必须修订，不能覆盖历史。

## 本地确定性检查

入口scripts/run.sh（Windows为scripts/run.ps1），固定主类SpecShapeCheck。先读[请求样例](templates/request.example.json)和[请求结构](schemas/request.schema.json)，填写本次真实输入后按工件约定执行。程序结构PASS不代表业务批准；UNKNOWN/NEEDS_CONFIRMATION必须保留原因。

## 输出与验证

`delta-spec.json/md`；baseline_behavior、deltas[]、business_rules[]、acceptance_criteria[]、invariants[]、oracle_refs[]、compatibility、unresolved[]、confirmation。未确认的 Spec 可用于评审，不作为实施授权。

使用[业务模板](templates/delta-spec.json)与[输出结构](schemas/delta-spec.schema.json)，脚本check-result单独保存，不手填程序事实。

## 个性化与停止

需规格模板、规则编号、错误码和非功能要求。监管指标/容量值没有来源时不编造；性能 AC 必须明确环境和测量方法。

## 按需参考

- [delta-spec-rules](references/delta-spec-rules.md)：对应步骤判断。
- [派生来源](references/derivation.md)：版本与增量开发。
- [验收场景](references/acceptance.md)：验证或排查时读取。
