# delta-spec-rules

结构：目标/非目标、baseline行为、delta、不变项、BR、AC、Oracle、兼容/数据/恢复约束、确认及未决项。ADDED新增；MODIFIED引用旧BR和前后差异；REMOVED保留tombstone/原因/影响。

AC按given/when/then可观察结果写，并关联BR和独立Oracle。金额/日期/幂等/异常用确认规则，不从当前实现推正确预期。技术方案另列，不把模型猜测写成需求。确认后改动修订ID/revision并重验。
