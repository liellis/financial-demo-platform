# S09 派生记录

- [templates/commands/specify.md](https://github.com/github/spec-kit/blob/623b09990faabf36bd5a1f47b457e0c0f711124e/templates/commands/specify.md)，Commit 623b09990faabf36bd5a1f47b457e0c0f711124e。
- [src/core/templates/workflows/propose.ts](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/src/core/templates/workflows/propose.ts)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。
- [schemas/spec-driven/schema.yaml](https://github.com/Fission-AI/OpenSpec/blob/9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461/schemas/spec-driven/schema.yaml)，Commit 9d4e5974e5c0d9a09b9c6c1e1eb0975e80ec4461。

- S09-D01：将上游新增能力导向改为存量系统的 ADDED/MODIFIED/REMOVED、当前行为、目标行为与不变项。
- S09-D02：删除生成分支、脚手架及上游路径假设；需求与技术设计分开，不把实现猜测写成需求。
- S09-D03：新增 BR→AC→Oracle、关键未决项、兼容/数据/回退约束及确认版本。

脚本为新增实现，方法引用不表示上游具备银行功能。上游许可保留，新增内容权利按项目交付约定。
